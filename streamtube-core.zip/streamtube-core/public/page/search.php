<?php
/**
 * The template for displaying video archive
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}
    
$template = streamtube_get_search_template_settings();

extract( $template );

?>
<?php get_header();?>

    <div class="page-main py-3">

        <div class="<?php echo esc_attr( join( ' ', streamtube_get_container_classes( $content_width ) ) ); ?>">

            <div class="page-header d-flex align-items-center justify-content-between py-4">
                <h1 class="page-title h5"><?php printf( esc_html__( 'Search result for "%s"', 'streamtube' ), get_search_query() ); ?></h1>

                <div class="ms-auto">
                    <?php get_template_part( 'template-parts/sortby' ); ?>
                </div>
            </div>

            <?php
            $query_args = array_merge( $GLOBALS['wp_query']->query_vars, array(
                'margin_bottom'         =>  4,
                'show_post_date'        =>  $post_date,
                'show_post_comment'     =>  true,
                'show_author_name'      =>  true,
                'hide_empty_thumbnail'  =>  true,                
                'hide_empty_thumbnail'  =>  $hide_empty_thumbnail,
                'thumbnail_size'        =>  'streamtube-image-medium',
                'posts_per_page'        =>  (int)$posts_per_column * (int)$rows_per_page,
                'paged'                 =>  get_query_var( 'page' ),
                'layout'                =>  $layout,
                'col_xxl'               =>  (int)$posts_per_column,
                'col_xl'                =>  (int)$col_xl,
                'col_lg'                =>  (int)$col_lg,
                'col_md'                =>  (int)$col_md,
                'col_sm'                =>  (int)$col_sm,
                'col'                   =>  (int)$col,
                'author_avatar'         =>  $author_avatar,
                'avatar_size'           =>  $layout != 'grid' ? 'sm' : 'md',
                'post_excerpt_length'   =>  $post_excerpt_length,
                'pagination'            =>  $pagination,
                'not_found_text'        =>  esc_html__( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.

', 'streamtube-core' )
            ) );

            /**
             *
             * Filter the query_args
             * 
             * @param  array $query_args
             *
             * @since  1.0.0
             * 
             */
            $query_args = apply_filters( 'streamtube/archive/video/query_args', $query_args );

            the_widget( 'Streamtube_Core_Widget_Posts', $query_args, array() );
            ?>

    	</div>
    </div>

<?php get_footer();?>