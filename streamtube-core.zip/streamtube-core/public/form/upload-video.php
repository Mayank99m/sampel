<?php 
/**
 *
 * Fires after open form
 *
 * @since  1.0.0
 * 
 */
do_action( 'streamtube/core/form/uploadvideo/before' );
?>

<div id="drag-drop-upload" class="drag-drop-upload upload-form__group">

	<?php if( ! current_user_can( 'publish_posts' ) ):?>

		<div class="alert alert-danger d-flex align-items-center mb-3">
			<span class="icon-cancel-circled h4 m-0"></span>
			<div>
				<?php esc_html_e( 'Sorry, You do not have permission to upload videos, please contact administrator for further assistance.', 'streamtube-core' ); ?>
			</div>
		</div>

	<?php endif;?>

	<label class="upload-form__label">
		<input name="video_file" type="file" accept="video/*" class="d-none video_file">
		<div class="top-50 start-50 translate-middle position-absolute text-center">
			<span class="icon icon-upload"></span>
			<h5>
				<?php esc_html_e( 'Click here to upload video file.', 'streamtube-core' ); ?>
			</h5>
		</div>
	</label>

	<div class="progress-wrap my-3">

		<div class="row">

			<div class="col-12 col-md-3">
				<div class="post-thumbnail ratio ratio-16x9 rounded overflow-hidden bg-dark"></div>
			</div>

			<div class="col-12 col-md-9 col__main">
				<p class="text-info my-3 mt-md-0">
					<span class="file-name fw-bold me-1">{filename}</span>
					<span class="text-muted">
						<?php esc_html_e( 'is being uploaded, please wait for a moment.', 'streamtube-core' ); ?>
					</span>
				</p>
				<div class="progress my-3" style="height: 25px;">
					<div class="progress-bar bg-success progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
				</div>
			</div>
		</div>

	</div>
</div>

<?php 
/**
 *
 * Fires after close form
 *
 * @since  1.0.0
 * 
 */
do_action( 'streamtube/core/form/uploadvideo/after' );