<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

include_once( 'overview.php' );
include_once( 'top-pageviews.php' );
include_once( 'channels.php' );
include_once( 'countries.php' );