<?php
if( ! defined('ABSPATH' ) ){
    exit;
}
?>
<div class="modal fade" id="modal-upload" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modal-upload-label" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
		<div class="modal-content step-wrap bg-white">
			<div class="modal-header bg-light">
				<h5 class="modal-title" id="modal-upload-label">
					<?php esc_html_e( 'Upload Video', 'streamtube-core' ); ?>
				</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php esc_attr_e( 'Close', 'streamtube-core' ); ?>"></button>
			</div>

			<div class="modal-body">

				<form id="form-submit-video" class="form-ajax form-steps upload-video-form">

					<div class="tab-content">
					
						<div class="tab-pane tab-upload-file active">
							<?php streamtube_core_load_template( 'form/upload-video.php', false ); ?>
						</div>

						<div class="tab-pane tab-details">

				            <div class="row">
				                <div class="col-12 col-xl-8">
			                        <?php streamtube_core_load_template( 'post/edit/details/main.php', false, array(
			                            'post'  =>  null,
			                            'args'  =>  array(
			                            	'post_type'	=>	'video',
			                            	'mode'		=>	'simple'
			                            )
			                        ) ); ?>
	                    		</div>
				                <div class="col-12 col-xl-4">
				                    <?php streamtube_core_load_template( 'post/edit/metaboxes.php', false, array(
			                            'post'  =>  null,
			                            'args'  =>  array(
			                            	'post_type'	=>	'video'
			                            )
			                        )  ); ?>
				                </div><!--.col-3-->
	                		</div>
						</div>

					</div>

					<input type="hidden" name="action" value="upload_video">
					<input type="hidden" name="post_ID" value="0">
					<input type="hidden" name="quick_update" value="1">
				</form>

			</div>

			<div class="modal-footer bg-light gap-3 d-none">

				<button form="form-submit-video" type="submit" class="btn btn-danger px-4 text-white btn-next">
					<?php esc_html_e( 'Save Changes', 'streamtube-core' ); ?>
				</button>

			</div>
		</div>
	</div>
</div>