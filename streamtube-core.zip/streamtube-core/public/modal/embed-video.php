<?php
if( ! defined('ABSPATH' ) ){
    exit;
}
?>
<div class="modal fade" id="modal-embed" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modal-upload-label" aria-hidden="true">
	<div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
		<div class="modal-content step-wrap bg-white">
			<div class="modal-header bg-light">
				<h5 class="modal-title" id="modal-embed-label">
					<?php esc_html_e( 'Embed Video', 'streamtube-core' ); ?>
				</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php esc_attr_e( 'Close', 'streamtube-core' ); ?>"></button>
			</div>

			<div class="modal-body">

				<form id="form-embed-video" class="form-ajax form-regular upload-video-form">

					<div class="tab-content">

						<?php if( ! current_user_can( 'publish_posts' ) ):?>

							<div class="alert alert-danger d-flex align-items-center mb-3">
								<span class="icon-cancel-circled h4 m-0"></span>
								<div>
									<?php esc_html_e( 'Sorry, You do not have permission to embed videos, please contact administrator for further assistance.', 'streamtube-core' ); ?>
								</div>
							</div>

						<?php endif;?>						
					
						<div class="tab-pane tab-upload-file active">
							<?php streamtube_core_the_field_control( array(
								'label'			=>	esc_html__( 'Source', 'streamtube-core' ),
								'name'			=>	'source',
								'type'			=>	'textarea',
								'required'		=>	true
							) );
							?>
						</div>

						<div class="tab-pane tab-details">

				            <div class="row">
				                <div class="col-12 col-xl-8">
			                        <?php streamtube_core_load_template( 'post/edit/details/main.php', false, array(
			                            'post'  =>  null,
			                            'args'  =>  array(
			                            	'post_type'	=>	'video',
			                            	'mode'		=>	'simple'
			                            )
			                        ) ); ?>
	                    		</div>
				                <div class="col-12 col-xl-4">
				                    <?php streamtube_core_load_template( 'post/edit/metaboxes.php', false, array(
			                            'post'  =>  null,
			                            'args'  =>  array(
			                            	'post_type'	=>	'video'
			                            )
			                        )  ); ?>
				                </div><!--.col-3-->
	                		</div>
						</div>

					</div>

					<input type="hidden" name="action" value="import_embed">
					<input type="hidden" name="post_ID" value="0">
					<input type="hidden" name="quick_update" value="1">

					<div class="form-submit d-flex">

						<button type="submit" class="btn btn-danger px-4 btn-next ms-auto">
							<span class="icon-plus"></span>
							<?php esc_html_e( 'Import', 'streamtube-core' ); ?>
						</button>

					</div>

				</form>

			</div>

		</div>
	</div>
</div>