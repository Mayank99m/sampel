<?php
if( ! defined('ABSPATH' ) ){
    exit;
}
$post_id = 0;

$postdata = $args['post'];

$args = $args['args'];

if( $postdata  ){
	$args['post_type'] = $postdata ->post_type;

	$post_id = $postdata->ID;
}

$hidden_taxes = array( 'video_tag', 'post_tag', 'post_format' );

if( is_post_type_viewable( $args['post_type'] )):

	$taxonomies = get_object_taxonomies( $args['post_type'], 'object' );

	if( $taxonomies ):

		for ($i=0; $i < count( $hidden_taxes ); $i++) { 
			if( array_key_exists( $hidden_taxes[$i] , $taxonomies ) ){
				unset( $taxonomies[ $hidden_taxes[$i]] );
			}
		}

		foreach ( $taxonomies as $tax => $object ):

			?>
			<div class="widget shadow-sm rounded bg-white border">

				<div class="widget-title-wrap m-0 p-3 bg-light">
				    <h2 class="widget-title no-after m-0">
				    	<?php echo apply_filters( 'streamtube/core/post/edit/tax/title', $object->label, $object, $tax );?>
				    </h2>
				</div>	

				<div class="widget-content p-3">

					<?php if( $object->hierarchical ):?>
						<ul class="list-unstyled checkboxes p-0">
							<?php
							if( ! function_exists( 'wp_terms_checklist' ) ){
								include ABSPATH . 'wp-admin/includes/template.php';
							}

							wp_terms_checklist( $post_id, array(
								'taxonomy'	=>	$tax
							) );
							?>
						</ul>
					<?php else:?>
						<?php
                        $tag_terms = get_the_terms( $post_id, $tax );

                        streamtube_core_the_field_control( array(
                    		'label'			=>	esc_html__( $object->label, 'streamtube-core' ),
                    		'name'			=>	sprintf( 'tax_input[%s][]', $tax ),
                    		'value'			=>	is_array( $tag_terms ) ? join(',', wp_list_pluck( $tag_terms, 'name' ) ) : '',
                            'data'          =>  array(
                                'data-role' =>  'tagsinput'
                            ),
                    		'wrap_class'	=>	'taginput-wrap'
                    	) );
						?>
					<?php endif;?>

				</div>		

			</div>
			<?php

		endforeach;

	endif;

endif;