<?php
if( ! defined('ABSPATH' ) ){
    exit;
}
?>
<div class="widget">

    <div class="widget-title-wrap d-flex">
        <h2 class="widget-title">
            <?php esc_html_e( 'Settings', 'streatube-core' );?>
        </h2>
    </div>

	<div class="profile-form-wrap">

		<?php 

		$page = 'settings';

		streamtube_core()->get()->user_dashboard->the_menu( array(
			'user_id'		=>	get_current_user_id(),
			'base_url'		=>	streamtube_core_get_user_dashboard_url( get_current_user_id(), $page ),
			'menu_classes'	=>	'nav-tabs secondary-nav',
			'item_classes'	=>	'text-secondary d-flex align-items-center'
		), $page );?>

		<div class="bg-white p-4 border-start border-right border-bottom border-end">
			<?php streamtube_core()->get()->user_dashboard->the_main( $page );?>
		</div>
		
	</div>
</div>

