<?php
if( ! defined('ABSPATH' ) ){
    exit;
}

streamtube_core_load_template( 'comment/table-comments.php', true, array() );