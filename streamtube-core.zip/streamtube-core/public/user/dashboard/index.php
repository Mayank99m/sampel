<?php get_header( 'dashboard' );?>

        <div id="dashboard-<?php echo get_queried_object_id();?>" class="user-dashboard overflow-hidden p-0">

            <?php streamtube_core_load_template( 'user/dashboard/menu.php' ); ?>

            <div class="col_main w-100">

                <?php printf(
                    '<div class="p-4 %s">',
                    function_exists( 'WC' ) ? 'has-woocommerce woocommerce' : ''
                );?>

                	<?php
                	/**
                	 *
                	 * Fires before dashboard main content
                	 *
                	 * @since  1.0.0
                	 * 
                	 */
                	do_action( 'streamtube/core/user/dashboard/main/before' );
                	?>

                	<?php streamtube_core()->get()->user_dashboard->the_main(); ?>

                	<?php
                	/**
                	 *
                	 * Fires aftr dashboard main content
                	 *
                	 * @since  1.0.0
                	 * 
                	 */
                	do_action( 'streamtube/core/user/dashboard/main/after' );
                	?>

                </div>

            </div>
        </div>

        <?php wp_footer();?>

        <style type="text/css">
            body.body-dashboard{overflow: hidden!important;}
            .has-preloader.disable-preloader {
                overflow-y: hidden!important;
            }
        </style>

    </body>

</html>