<?php
if( ! defined('ABSPATH' ) ){
    exit;
}

define( 'STREAMTUBE_CORE_IS_DASHBOARD', true );

wp_enqueue_script( 'bootstrap-masonry.pkgd' );

/**
 *
 * Fires before user dashboard
 *
 * @since 1.0.8
 * 
 */
do_action( 'streamtube/user/dashboard/before' );
?>

<div class="row" data-masonry="<?php echo esc_attr( json_encode( array( 'percentPosition'=>true ) ) );?>">

	<?php dynamic_sidebar( 'user-dashboard' ); ?>

</div>

<?php
/**
 *
 * Fires after user dashboard
 *
 * @since 1.0.8
 * 
 */
do_action( 'streamtube/user/dashboard/after' );