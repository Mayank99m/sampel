<div class="tablenav bottom mb-4">

	<div class="d-block d-md-flex align-items-start">

		<div class="ms-auto">
			<?php include( 'pagination.php' ) ?>
		</div>

	</div>

</div>