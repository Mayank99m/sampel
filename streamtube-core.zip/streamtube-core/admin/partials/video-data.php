<?php
/**
 *
 * The admin metabox template file.
 * 
 */
if( ! defined('ABSPATH' ) ){
    exit;
}
?>
<div class="metabox-wrap">

    <?php 
    /**
     * Fires before video metadata fields.
     *
     * @param $object $post
     */
    do_action( 'streamtube/core/admin/metabox/videodata/before', $post );
    ?>

    <div class="field-group">
        <label for="video_url"><?php esc_html_e( 'Media Id', 'streamtube-core' ); ?></label>
        
        <?php printf(
            '<textarea name="video_url" id="video_url" class="regular-text input-field">%s</textarea>',
            esc_textarea( $this->plugin()->post->get_source() )
        );?>

        <p class="description">
            <?php esc_html_e( 'Upload a video file or paste a link/iframe code', 'streamtube-core' );?>
        </p>
        <button id="upload-file" type="button" class="button button-primary button-upload" data-media-type="video">
            <?php esc_html_e( 'Upload a file', 'streamtube-core' );?>
        </button>                
    </div>

    <div class="field-group">
        <label for="length"><?php esc_html_e( 'Video Length', 'streamtube-core' ); ?></label>

        <?php printf(
            '<input type="number" name="length" id="length" class="regular-text" value="%s">',
            esc_attr( $this->plugin()->post->get_length( $post->ID ) )
        );?>
    </div>

    <div class="field-group">
        <label for="aspect_ratio"><?php esc_html_e( 'Aspect Ratio', 'streamtube-core' ); ?></label>

        <select id="aspect_ratio" name="aspect_ratio" class="regular-text">

            <?php 
            $ratios = streamtube_core_get_ratio_options();

            foreach ( $ratios as $key => $value ): ?>
                    
                    <?php printf(
                        '<option value="%s" %s>%s</option>',
                        esc_attr( $key ),
                        selected($this->plugin()->post->get_aspect_ratio( $post->ID ), $key, false ),
                        esc_html( $value )
                    );?>

            <?php endforeach ?>

        </select>
    </div>

    <?php 
    /**
     * Fires after video metadata fields.
     *
     * @param $object $post
     */
    do_action( 'streamtube/core/admin/metabox/videodata/after', $post );
    ?>

    <?php
    wp_nonce_field( $this->nonce, $this->nonce );
    ?>

</div>