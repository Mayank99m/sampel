<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://themeforest.net/user/phpface
 * @since      1.0.0
 *
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/admin
 * @author     phpface <nttoanbrvt@gmail.com>
 */

if( ! defined('ABSPATH' ) ){
	exit;
}

class Streamtube_Core_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		wp_enqueue_style( 
			'select2', 
			plugin_dir_url( dirname( __FILE__ ) ) . 'public/assets/vendor/select2/select2.min.css', 
			array(), 
			filemtime( plugin_dir_path( dirname( __FILE__ ) ) . 'public/assets/vendor/select2/select2.min.css' )
		);	

		wp_enqueue_style( 
			$this->plugin_name, 
			plugin_dir_url( __FILE__ ) . 'assets/css/streamtube-core-admin.css', 
			array(), 
			filemtime( plugin_dir_path( __FILE__ ) . 'assets/css/streamtube-core-admin.css' ), 
			'all' 
		);

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		wp_enqueue_script(
			'select2',
			plugin_dir_url( dirname( __FILE__ ) ) . 'public/assets/vendor/select2/select2.min.js',
			array( 'jquery' ),
			filemtime( plugin_dir_path( dirname( __FILE__ ) ) . 'public/assets/vendor/select2/select2.min.js' ),
			true
		);

		wp_enqueue_script( 
			'streamtube-core-admin', 
			plugin_dir_url( __FILE__ ) . 'assets/js/streamtube-core-admin.js', 
			array( 'jquery' ), 
			filemtime( plugin_dir_path( __FILE__ ) . 'assets/js/streamtube-core-admin.js' ), 
			true 
		);

		wp_localize_script( 'streamtube-core-admin', 'streamtube', array(
			'admin_url'	=>	esc_url_raw( admin_url( '/' ) ),
			'rest_url'	=>	esc_url_raw( rest_url() ),
			'nonce'		=>	wp_create_nonce( 'wp_rest' ),
			'generate'	=>	esc_html__( 'Generate', 'streamtube-core' ),
			'mediaid_not_found'	=>	esc_html__( 'Media Id was not found', 'streamtube-core' ),
			'remove_featured_image'	=>	esc_html__( 'Remove featured image', 'streamtube-core' )
		) );
	}
}
