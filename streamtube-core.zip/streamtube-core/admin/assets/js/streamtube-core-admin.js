(function( $ ) {
	'use strict';

	//$( '#video-data' ).appendTo( '#titlediv' );
	
	$(function() {
		if( $('body' ).hasClass( 'post-type-video' ) ){
			/**
			 * Auto insert generate image button
			 */
			var button = '';

			button = '<div class="metabox-wrap">';
				button += '<button type="button" id="button-generate-thumb-image" class="button button-primary">';
					button += streamtube.generate;
					button += '<span class="spinner"></span>';
				button += '</button>';
			button += '</div>';
			$( '#postimagediv' ).append( button );
		}
	});
	
	/**
	 *
	 * Widget TabJS handler
	 *
	 * @since  1.0.0
	 * 
	 */
	$( document ).on( 'click', '.widget-content .widget-tabs a', function(e){

		e.preventDefault();

		var parent	=	$(this).closest( '.widget-tabs' );
		var href 	=	$(this).attr( 'href' );

		parent.find( '.nav-link' ).removeClass( 'active' );

		$(this).addClass( 'active' );
		

		parent.next().find( '.tab-pane' ).removeClass( 'active' );

		parent.next().find( href ).addClass( 'active' );

		parent.next().find( '.current-tab' ).val( href.replace( '#', '' ) );
	});

	/**
	 * Post Type selector
	 *
	 * @since  1.0.0
	 * 
	 */
	$( document ).on( 'change', '.widget-content select.post-type', function(e){

		var postType 	=	$(this).val();
		var parent 		=	$(this).closest( 'div.field-control' );

		parent.next().find( '.taxonomy' ).removeClass( 'active' );
		parent.next().find( '.taxonomy-' + postType ).addClass( 'active' );
	});

	/**
	 *
	 * Remove error class of the fields
	 *
	 * @sice 1.0.6
	 * 
	 */
	$( document ).on( 'change', '.metabox-wrap .regular-text', function(e){
		$(this).removeClass( 'error' );
	});

	/**
	 *
	 * Upload file button handler
	 * @since  1.0.0
	 * 
	 */
	$( document ).on( 'click', 'button.button-upload', function(e){
		e.preventDefault();

		var button = $(this);
		var mediaType = button.attr( 'data-media-type' );

		var frame;
		
		// If the media frame already exists, reopen it.
		if ( frame ) {
			frame.open();
			return;
	    }
		
		// Create a new media frame
		frame = wp.media({	
			library: { type: mediaType },
			multiple: false  // Set to true to allow multiple files to be selected
		});	
		
		 // When an video is selected in the media frame...
	    frame.on( 'select', function() {
	    	
	    	// Get media attachment details from the frame state
	    	var attachment = frame.state().get('selection').first().toJSON();

	    	var attachment_id	=	attachment.id;
	    	var mime			=	attachment.mime;
	    	var subtype			=	attachment.subtype; // known as techorder.
	    	var url				=	attachment.url;

	    	var mediaId = '';
	    	if( mediaType == 'video' ){
	    		mediaId = attachment_id;
	    	}
	    	else{
	    		mediaId = url;
	    		button
	    		.closest( '.field-group' )
				.find( 'button#button-featured-image-2' )
				.html( '<img src="'+mediaId+'">' );
	    	}

	    	button
	    	.closest( '.field-group' )
	    	.find( '.input-field' )
	    	.val( mediaId )
	    	.removeClass( 'error' );

	    });
	    
    	 // Finally, open the modal on click
        frame.open();		
	});

	/**
	 *
	 * Generate webp image
	 * 
	 */
	$( document ).on( 'click', '#button-generate-webp-image', function(e){
		e.preventDefault();

		var button = $(this);
		var mediaId = parseInt( $( '#video-data' ).find( 'textarea[name=video_url]' ).val() );
		var postId = button.closest( 'form' ).find( 'input[name=post_ID]' ).val();

		if( isNaN( mediaId ) ){
			button.closest( 'form' ).find( 'textarea[name=video_url]' ).addClass( 'error' ).focus();

            $('html, body').animate({
                scrollTop: $( '#video-data' ).offset().top
            }, 1000 );

			return false;
		}

		$.ajax( {
			url: streamtube.rest_url + 'wp-video-encoder/v1/generate-image',
			method: 'POST',
			beforeSend: function ( xhr ) {
				xhr.setRequestHeader( 'X-WP-Nonce', streamtube.nonce );

				button
				.attr( 'disabled', 'disabled' )
				.find( '.spinner' )
				.addClass( 'is-active' );

				button
				.closest( '.field-group' )
				.find( '.alert' )
				.remove();
			},
			data:{
				'attachment_id' : mediaId,
				'parent'		: postId,
				'type'			: 'webp'
			}
		} ).done( function ( response ) {

			if( response.success == false ){
				button.after( '<div class="alert error">'+response.data[0].message+'</div>' );
			}else{
				button
				.closest( '.field-group' )
				.find( 'input[name=thumbnail_image_url_2]' )
				.val( response.data.image_url );

				button
				.closest( '.field-group' )
				.find( 'button#button-featured-image-2' )
				.html( '<img src="'+response.data.image_url+'">' );
			}

			button
			.removeAttr( 'disabled' )
			.find( '.spinner' )
			.removeClass( 'is-active' );

		} );

	} );

	/**
	 *
	 * Generate thumbnail image
	 * 
	 */
	$( document ).on( 'click', '#button-generate-thumb-image', function(e){
		e.preventDefault();
		var button = $(this);
		var wrapper = button.closest( '#postimagediv' );
		var mediaId = $( '#video-data' ).find( 'textarea[name=video_url]' ).val();
		var postId = button.closest( 'form' ).find( 'input[name=post_ID]' ).val();

		if( mediaId == "" ){
			
			button.closest( 'form' ).find( 'textarea[name=video_url]' ).addClass( 'error' ).focus();

            $('html, body').animate({
                scrollTop: $( '#video-data' ).offset().top
            }, 1000 );

			return false;
		}

		$.ajax( {
			url: streamtube.rest_url + 'streamtube/v1/generate-image',
			method: 'POST',
			beforeSend: function ( xhr ) {
				xhr.setRequestHeader( 'X-WP-Nonce', streamtube.nonce );

				button
				.attr( 'disabled', 'disabled' )
				.find( '.spinner' )
				.addClass( 'is-active' );

				button
				.closest( '.metabox-wrap' )
				.find( '.alert' )
				.remove();				
			},
			data:{
				'mediaid'	: mediaId,
				'parent'	: postId
			}
		} ).done( function ( response ) {

			if( response.success == false ){
				var output = '';
				output += '<div class="alert error">';
					output += '<strong>'+response.data[0].code+': </strong>';
					output += response.data[0].message;
				output += '</div>';
				button.after( output );
			}

			if( response.success == true ){
				var imgTag = '<p class="hide-if-no-js"><a href="'+streamtube.admin_url+'media-upload.php?post_id='+postId+'&type=image&TB_iframe=1" id="set-post-thumbnail" class="thickbox">';
					imgTag += '<img src="'+ response.data.thumbnail_url +'">';
				imgTag += '</a></p>';

				imgTag += '<p class="hide-if-no-js"><a href="#" id="remove-post-thumbnail">'+streamtube.remove_featured_image+'</a></p>';

				wrapper.find( '.inside .hide-if-no-js' ).remove();
				wrapper.find( '.inside' ).prepend( imgTag );

				wrapper.find( '#_thumbnail_id' ).val( response.data.thumbnail_id );

			}

			button
			.removeAttr( 'disabled' )
			.find( '.spinner' )
			.removeClass( 'is-active' );
		} );
	});	

	$( document ).on( 'change', '.restrict-content-wrap #restrict_content_for', function(e){
		var value = $(this).val();

		var td = $(this).closest( 'td' );

		td.find( '.section-apply-for' ).hide();

		td.find( '#section-' + value ).show();

		if( $.inArray( value, [ 'roles', 'capabilities' ] ) !== -1 ){
			$( '#section-operator' ).show();
		}else{
			$( '#section-operator' ).hide();
		}
	});

})( jQuery );
