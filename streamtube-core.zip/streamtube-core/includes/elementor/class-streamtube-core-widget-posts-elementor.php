<?php
/**
 * Define the custom posts elementor widget functionality
 *
 *
 * @link       https://themeforest.net/user/phpface
 * @since      1.0.0
 *
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 */

/**
 *
 * @since      1.0.0
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined('ABSPATH' ) ){
    exit;
}

class Streamtube_Core_Widget_Posts_Elementor extends \Elementor\Widget_Base{

    public function get_name(){
        return 'streamtube_posts_elementor';
    }

    public function get_title(){
        return esc_html__( 'Post List', 'streamtube-core' );
    }

    public function get_icon(){
        return 'eicon-video-playlist';
    }

    public function get_keywords(){
        return array( 'streamtube', 'posts', 'streamtube' );
    }

    public function get_categories(){
        return array( 'streamtube' );
    }

    /**
     *
     * Get default supported post types
     * 
     * @return array
     *
     * @since  1.0.0
     * 
     */
    private function get_post_types(){
        $r = array(
            'post'      =>  esc_html__( 'Post', 'streamtube-core' ),
            'video'     =>  esc_html__( 'Video', 'streamtube-core' )
        );

        return $r;
    }

    private function get_term_options( $terms ){
        $options = array();

        if( ! $terms ){
            return $options;
        }

        foreach( $terms as $term ){
            $options[ $term->slug ] = $term->name;
        }

        return $options;
    }

    protected function register_controls(){

        $this->start_controls_section(
            'section-appearance',
            array(
                'label'     =>  esc_html__( 'Appearance', 'streamtube-core' ),
                'tab'       =>  \Elementor\Controls_Manager::TAB_CONTENT
            )
        );

            $this->add_control(
                'title',
                array(
                    'label'     =>  esc_html__( 'Title', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::TEXT
                )
            );

            $this->add_control(
                'icon',
                array(
                    'label'     =>  esc_html__( 'Icon', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::TEXT,
                    'description'   =>  esc_html__( 'Enter an icon class name', 'streamtube-core' )
                )
            );

            $this->add_control(
                'style',
                array(
                    'label'     =>  esc_html__( 'Style', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  'light',
                    'options'   =>  array(
                        'dark'  =>  esc_html__( 'Dark', 'streamtube-core' ),
                        'light'  =>  esc_html__( 'Light', 'streamtube-core' )
                    )
                )
            );            

            $this->add_control(
                'posts_per_page',
                array(
                    'label'     =>  esc_html__( 'Posts Per Page', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  10
                )
            );

            $this->add_control(
                'pagination',
                array(
                    'label'     =>  esc_html__( 'Pagination', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  '',
                    'options'   =>  array(
                        ''          =>  esc_html__( 'None', 'streamtube-core' ),
                        'numbers'   =>  esc_html__( 'Numbers', 'streamtube-core' ),
                        'scroll'    =>  esc_html__( 'Load on scroll', 'streamtube-core' ),
                        'click'     =>  esc_html__( 'Load on click', 'streamtube-core' )
                    )
                )
            );

            $this->add_control(
                'post_excerpt_length',
                array(
                    'label'     =>  esc_html__( 'Post excerpt length', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  0,
                    'description'   =>  esc_html__( 'Limit post excerpt length, 0 is disabled', 'streamtube-core' )
                )
            );

            $this->add_control(
                'more_link',
                array(
                    'label'     =>  esc_html__( 'Show view more link', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  ''
                )
            );

            $this->add_control(
                'more_link_url',
                array(
                    'label'     =>  esc_html__( 'Custom view more link', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::TEXT,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'e.g: http://domain.com/latest-posts', 'streamtube-core' ),
                    'condition' =>  array(
                        'more_link'  =>  'yes'
                    )                    
                )
            );

            $this->add_control(
                'show_post_date',
                array(
                    'label'     =>  esc_html__( 'Show post date', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  'normal',
                    'options'   => array(
                        ''          =>  esc_html__( 'None', 'streamtube-core' ),
                        'normal'    =>  esc_html__( 'Normal', 'streamtube-core' ),
                        'diff'      =>  esc_html__( 'Diff', 'streamtube-core' ),
                    )
                )
            );

            $this->add_control(
                'show_post_comment',
                array(
                    'label'     =>  esc_html__( 'Show post comment', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  'yes'
                )
            );  

            $this->add_control(
                'show_author_name',
                array(
                    'label'     =>  esc_html__( 'Show author name', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  'yes'
                )
            );

            $this->add_control(
                'author_avatar',
                array(
                    'label'     =>  esc_html__( 'Show post author avatar', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  ''
                )
            );

            $this->add_control(
                'avatar_size',
                array(
                    'label'     =>  esc_html__( 'Avatar size', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  'md',
                    'options'   =>  array(
                        'sm'    =>  esc_html__( 'Small', 'streamtube-core' ),
                        'md'    =>  esc_html__( 'Medium', 'streamtube-core' ),
                        'lg'    =>  esc_html__( 'Large', 'streamtube-core' )
                    ),
                    'condition' =>  array(
                        'author_avatar' =>  'yes'
                    )
                )
            );           

            $this->add_control(
                'hide_thumbnail',
                array(
                    'label'     =>  esc_html__( 'Hide thumbnail image', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  ''
                )
            );

            $this->add_control(
                'thumbnail_size',
                array(
                    'label'     =>  esc_html__( 'Thumbnail Image Size', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::TEXT,
                    'default'   =>  'streamtube-image-medium',
                    'condition' =>  array(
                        'hide_thumbnail'    =>  ''
                    )   
                )
            );                        

            $this->add_control(
                'thumbnail_ratio',
                array(
                    'label'     =>  esc_html__( 'Thumbnail Image Ratio', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  get_option( 'thumbnail_ratio', '16x9' ),
                    'options'   =>   array(
                        '16x9'  =>  esc_html__( 'Landscape', 'streamtube-core' ),
                        '9x16'  =>  esc_html__( 'Portrait', 'streamtube-core' )
                    ),
                    'condition' =>  array(
                        'hide_thumbnail'    =>  ''
                    )   
                )
            );

            $this->add_control(
                'hide_empty_thumbnail',
                array(
                    'label'     =>  esc_html__( 'Hide empty thumbnail posts', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  ''
                )
            );

            $this->add_control(
                'hide_if_empty',
                array(
                    'label'     =>  esc_html__( 'Hide widget if no posts found', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  ''
                )
            );        

        $this->end_controls_section();


        $this->start_controls_section(
            'section-layout',
            array(
                'label'     =>  esc_html__( 'Layout', 'streamtube-core' ),
                'tab'       =>  \Elementor\Controls_Manager::TAB_CONTENT
            )
        );

            $this->add_control(
                'layout',
                array(
                    'label'     =>  esc_html__( 'Layout', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  'grid',
                    'options'   =>  array(
                        'grid'      =>  esc_html__( 'Grid', 'streamtube-core' ),
                        'list_xs'   =>  esc_html__( 'List Extra Small', 'streamtube-core' ),
                        'list_sm'   =>  esc_html__( 'List Small', 'streamtube-core' ),
                        'list_md'   =>  esc_html__( 'List Medium', 'streamtube-core' ),
                        'list_lg'   =>  esc_html__( 'List Large', 'streamtube-core' ),
                        'list_xl'   =>  esc_html__( 'List Extra Large', 'streamtube-core' ),
                        'list_xxl'   =>  esc_html__( 'List Extra Extra Large', 'streamtube-core' )
                    )
                )
            );

            $this->add_control(
                'title_size',
                array(
                    'label'     =>  esc_html__( 'Title Size', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  '',
                    'options'   =>  array(
                        ''  =>  esc_html__( 'Default', 'streamtube-core' ),
                        'md'    =>  esc_html__( 'Medium', 'streamtube-core' ),
                        'lg'    =>  esc_html__( 'Large', 'streamtube-core' ),
                        'xl'    =>  esc_html__( 'Extra Large', 'streamtube-core' ),
                        'xxl'    =>  esc_html__( 'Extra Extra Large', 'streamtube-core' )
                    ),
                    'description'   =>  esc_html__( 'Post Title font size', 'streamtube-core' )
                )
            );             

            $this->add_control(
                'margin',
                array(
                    'label'     =>  esc_html__( 'Margin', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  'yes',
                    'description'   =>  esc_html__( 'Enable margin between items', 'streamtube-core' )
                )
            );

            $this->add_control(
                'margin_bottom',
                array(
                    'label'     =>  esc_html__( 'Margin Bottom', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  4,
                    'description'   =>  esc_html__( 'Set margin bottom: from 1 to 5', 'streamtube-core' )
                )
            );                         

            $this->add_control(
                'overlay',
                array(
                    'label'     =>  esc_html__( 'Overlay', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  '',
                    'condition' =>  array(
                        'layout'    =>  'grid'
                    )
                )
            );        

            $this->add_control(
                'col_xxl',
                array(
                    'label'     =>  esc_html__( 'Extra extra large ≥1400px', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  4
                )
            );

            $this->add_control(
                'col_xl',
                array(
                    'label'     =>  esc_html__( 'Extra large ≥1200px', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  4
                )
            );

            $this->add_control(
                'col_lg',
                array(
                    'label'     =>  esc_html__( 'Large ≥992px', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  2
                )
            );

            $this->add_control(
                'col_md',
                array(
                    'label'     =>  esc_html__( 'Medium ≥768px', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  2
                )
            );

            $this->add_control(
                'col_sm',
                array(
                    'label'     =>  esc_html__( 'Small ≥576px', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  1
                )
            );

            $this->add_control(
                'col',
                array(
                    'label'     =>  esc_html__( 'Extra small <576px', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  1
                )
            );


        $this->end_controls_section();

        $this->start_controls_section(
            'section-slide',
            array(
                'label'     =>  esc_html__( 'Slide', 'streamtube-core' ),
                'tab'       =>  \Elementor\Controls_Manager::TAB_CONTENT
            )
        );  

            $this->add_control(
                'slide',
                array(
                    'label'     =>  esc_html__( 'Sliding', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Enable sliding', 'streamtube-core' )
                )
            );

            $this->add_control(
                'slide_rows',
                array(
                    'label'     =>  esc_html__( 'Rows', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  '1'
                )
            );  

           $this->add_control(
                'slide_dots',
                array(
                    'label'     =>  esc_html__( 'Dots', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Show dot indicators', 'streamtube-core' )
                )
            );

           $this->add_control(
                'slide_arrows',
                array(
                    'label'     =>  esc_html__( 'Arrows', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Show Prev/Next Arrows', 'streamtube-core' )
                )
            );

           $this->add_control(
                'slide_center_mode',
                array(
                    'label'     =>  esc_html__( 'Center mode', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Enables centered view with partial prev/next slides', 'streamtube-core' )
                )
            );

           $this->add_control(
                'slide_infinite',
                array(
                    'label'     =>  esc_html__( 'Infinite', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Infinite Loop Sliding', 'streamtube-core' )
                )
            );           

           $this->add_control(
                'slide_speed',
                array(
                    'label'     =>  esc_html__( 'Speed', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  '2000',
                    'description'   =>  esc_html__( 'Slide Animation Speed', 'streamtube-core' )
                )
            );           

           $this->add_control(
                'slide_autoplay',
                array(
                    'label'     =>  esc_html__( 'Autoplay', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Enables Autoplay', 'streamtube-core' )
                )
            );

           $this->add_control(
                'slide_autoplaySpeed',
                array(
                    'label'     =>  esc_html__( 'Autoplay Speed', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  '2000',
                    'description'   =>  esc_html__( 'Autoplay Speed in milliseconds', 'streamtube-core' )
                )
            );           

        
        $this->end_controls_section();

        $this->start_controls_section(
            'section-datasource',
            array(
                'label'     =>  esc_html__( 'Data Source', 'streamtube-core' ),
                'tab'       =>  \Elementor\Controls_Manager::TAB_CONTENT
            )
        );

            $this->add_control(
                'post_type',
                array(
                    'label'     =>  esc_html__( 'Post Type', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  'video',
                    'options'   =>  $this->get_post_types()
                )
            );

            foreach( $this->get_post_types() as $post_type => $post_type_label ){
                if( is_post_type_viewable( $post_type )){
                    $taxonomies = get_object_taxonomies( $post_type, 'object' );

                    if( $taxonomies ){

                        foreach ( $taxonomies as $tax => $object ){

                            $terms = get_terms( array(
                                'taxonomy'      =>  $tax,
                                'hide_empty'    =>  false
                            ) );

                            $this->add_control(
                                'tax_query_' . $tax,
                                array(
                                    'label'     =>  $object->label,
                                    'type'      =>  \Elementor\Controls_Manager::SELECT2,
                                    'multiple'  =>  true,
                                    'default'   =>  '',
                                    'condition' =>  array(
                                        'post_type' =>  $post_type
                                    ),
                                    'options'   =>  $this->get_term_options( $terms )
                                )
                            );

                        }
                    }
                }
            }

            $this->add_control(
                'search',
                array(
                    'label'     =>  esc_html__( 'Keyword', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::TEXT,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Show posts based on a keyword search', 'streamtube' )
                )
            );

            $this->add_control(
                'post_status',
                array(
                    'label'     =>  esc_html__( 'Status', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT2,
                    'multiple'  =>  true,
                    'default'   =>  array( 'publish' ),
                    'options'   =>  array(
                        'publish'   =>  esc_html__( 'Publish', 'streamtube-core' ),
                        'pending'   =>  esc_html__( 'Pending', 'streamtube-core' ),
                        'private'   =>  esc_html__( 'Private', 'streamtube-core' ),
                        'any'       =>  esc_html__( 'Any', 'streamtube-core' )
                    )
                )
            );
          
        $this->end_controls_section();

        $this->start_controls_section(
            'section-comment',
            array(
                'label'     =>  esc_html__( 'Comment', 'streamtube-core' ),
                'tab'       =>  \Elementor\Controls_Manager::TAB_CONTENT
            )
        );

            $this->add_control(
                'comment_count',
                array(
                    'label'     =>  esc_html__( 'Comment Count', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::NUMBER,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Retrieve posts with with given comment count', 'streamtube-core' )
                )
            );

            $this->add_control(
                'comment_compare',
                array(
                    'label'     =>  esc_html__( 'Comment Compare', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::TEXT,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Possible values are ‘=’, ‘!=’, ‘>’, ‘>=’, ‘<‘, ‘<=’', 'streamtube-core' )
                )
            );            

        $this->end_controls_section();

        $this->start_controls_section(
            'section-date',
            array(
                'label'     =>  esc_html__( 'Date', 'streamtube-core' ),
                'tab'       =>  \Elementor\Controls_Manager::TAB_CONTENT
            )
        );

            $this->add_control(
                'date_before',
                array(
                    'label'     =>  esc_html__( 'Date Before', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::TEXT,
                    'default'   =>  ''
                )
            );

            $this->add_control(
                'date_after',
                array(
                    'label'     =>  esc_html__( 'Date After', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::TEXT,
                    'default'   =>  ''
                )
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'section-user',
            array(
                'label'     =>  esc_html__( 'User', 'streamtube-core' ),
                'tab'       =>  \Elementor\Controls_Manager::TAB_CONTENT
            )
        );

            $this->add_control(
                'current_logged_in',
                array(
                    'label'     =>  esc_html__( 'Current Logged In User', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Retrieve posts of current logged in user', 'streamtube-core' )
                )
            );

            $this->add_control(
                'current_author',
                array(
                    'label'     =>  esc_html__( 'Current Author', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                    'default'   =>  '',
                    'description'   =>  esc_html__( 'Retrieve posts of current author', 'streamtube-core' )
                )
            );

            if( function_exists( 'run_wp_user_follow' ) ):
                $this->add_control(
                    'current_logged_in_following',
                    array(
                        'label'     =>  esc_html__( 'Current Logged-in User\'s Following', 'streamtube-core' ),
                        'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                        'default'   =>  '',
                        'description'   =>  esc_html__( 'Retrieve current logged-in user\'s following', 'streamtube-core' )
                    )
                ); 

                $this->add_control(
                    'current_author_following',
                    array(
                        'label'     =>  esc_html__( 'Current Author\'s Following', 'streamtube-core' ),
                        'type'      =>  \Elementor\Controls_Manager::SWITCHER,
                        'default'   =>  '',
                        'description'   =>  esc_html__( 'Retrieve current author\'s following', 'streamtube-core' )
                    )
                );
            endif;
    
        $this->end_controls_section();

        $this->start_controls_section(
            'section-order',
            array(
                'label'     =>  esc_html__( 'Order', 'streamtube-core' ),
                'tab'       =>  \Elementor\Controls_Manager::TAB_CONTENT
            )
        );

            $this->add_control(
                'orderby',
                array(
                    'label'     =>  esc_html__( 'Order by', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  'date',
                    'options'   =>  streamtube_core_get_orderby_options()
                )
            );

            $this->add_control(
                'order',
                array(
                    'label'     =>  esc_html__( 'Order', 'streamtube-core' ),
                    'type'      =>  \Elementor\Controls_Manager::SELECT,
                    'default'   =>  'DESC',
                    'options'   =>  array(
                        'ASC'               =>  esc_html__( 'Ascending', 'streamtube-core' ),
                        'DESC'              =>  esc_html__( 'Descending (default).', 'streamtube-core' )
                    )
                )
            );               

        $this->end_controls_section();                
    }

    protected function content_template() {

    }

    public function render_plain_content( $instance = array() ) {

    }

    protected function render(){

        $instance = $this->get_settings_for_display();

        the_widget( 'Streamtube_Core_Widget_Posts', $instance, array(
            'before_widget' => '<div class="widget widget-elementor posts-widget streamtube-widget">',
            'after_widget'  => '</div>',
            'before_title'  => '<div class="widget-title-wrap"><h2 class="widget-title d-flex align-items-center">',
            'after_title'   => '</h2></div>'
        ) );
    }
}
\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Streamtube_Core_Widget_Posts_Elementor() );