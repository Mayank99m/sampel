<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define the rest functionality.
 *
 * @since      1.0.8
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 * @author     phpface <nttoanbrvt@gmail.com>
 */
class StreamTube_Core_Google_SiteKit_Rest_Controller extends StreamTube_Core_Rest_API{

    /**
     *
     * Check if cache is enabled.
     * 
     * @return boolean
     */
    protected function is_caching(){
        $expiration = absint( get_option( 'sitekit_reports_expiration', 3600 ) );

        if( ! $expiration || $expiration == 0 ){
            return false;
        }

        return $expiration;
    }    

    /**
     *
     * Get date ranges
     * 
     * @param  WP_Rest_Request  $request
     * @param  boolean $compare
     * @return array or WP_Error
     */
    protected function get_date_ranges( $request, $compare = true, $page_path = '' ){

        $dateRanges = array();

        $date_diff = 0;

        $startDate  = $endDate = $compareStartDate = $compareEndDate = '';

        if( ! $request['start_date'] ){
            $request['start_date'] = '7daysAgo';
        }

        if( ! $request['end_date'] ){
            $request['end_date'] = 'yesterday';
        }

        if( $request['start_date'] == 'today' ){
            $request['end_date'] = 'today';
        }

        if( $request['start_date'] == 'all' ){
            $page_id = url_to_postid( trailingslashit( home_url('/') ) . $page_path );

            if( $page_id ){
                $request['start_date'] = date( 'Y-m-d', strtotime( get_post( $page_id )->post_date ) );
            }
            else{
                $request['start_date'] = get_option( 'site_start_date', '2006-01-01' );
            }

            $request['end_date'] = 'today';
        }

        $startDate = date( 'Y-m-d', strtotime( $request['start_date'] ) );
        $endDate = date( 'Y-m-d', strtotime( $request['end_date'] ) );

        $date_diff = (int)date_diff( date_create( $startDate ), date_create( $endDate ))->format("%R%a");

        if( $date_diff < 0 ){
            return new WP_Error( 
                'invalid_date_range',
                esc_html__( 'Invalid Date Ranges', 'streamtube-core' )
            );
        }

        if( $compare ){
            $compareEndDate = date( 'Y-m-d', strtotime( "-1 day", strtotime( $startDate ) ));            
            $compareStartDate = date( 'Y-m-d', strtotime( "-{$date_diff} days", strtotime( $compareEndDate ) ));
        }

        $dateRanges[] = compact( 'startDate', 'endDate' );

        if( $compareStartDate && $compareEndDate ){
            $dateRanges[] = array(
                'startDate' =>  $compareStartDate,
                'endDate'   =>  $compareEndDate
            );
        };

        return $dateRanges;
    }

    /**
     *
     * Get given user post paths
     *
     * @since 1.0.8
     *
     * @return array
     * 
     */
    protected function get_user_post_paths(){

        $user_id = get_current_user_id();

        $post_types = array( 'video', 'post' );

        $page_paths = $post_ids = array();

        if( count_user_posts( $user_id, $post_types, true ) == 0 ){
            return $page_paths;
        }        

        $post_args = array(
            'author'            => $user_id,
            'post_type'         => $post_types,
            'post_status'       => 'publish',
            'posts_per_page'    => -1
        );

        /**
         *
         * Filter query args
         * 
         * @var array $post_args
         *
         * @since 1.0.8
         * 
         */
        $posts = get_posts( apply_filters( 'streamtube/core/googlesitekit/user/post_paths_args', $post_args ) );

        if( ! $posts ){
            return $page_paths;
        }

        $post_ids = wp_list_pluck( $posts, 'ID' );

        for ( $i=0; $i < count( $post_ids ); $i++) { 
            //$page_paths[] = str_replace( home_url('/'), '/', get_permalink( $post_ids[$i] ) );
            
            $path = str_replace( home_url( '/' ), '/', get_permalink( $post_ids[$i] ) );

            $page_paths[] = apply_filters( 'streamtube/core/page/path', $path, $post_ids[$i] );
        }        

        return $page_paths;
    }

    /**
     *
     * Get all current user page paths
     * 
     * @return array
     *
     * @since 1.0.8
     * 
     */
    protected function get_user_page_paths(){

        $page_paths = array();

        $user_id = get_current_user_id();

        if( apply_filters( 'streamtube/core/googlesitekit/user/page_paths/include_profile', true ) === true ){
            $page_paths[] = str_replace( home_url('/'), '/', get_author_posts_url( $user_id ) );
        }

        $page_paths = array_merge( $page_paths, $this->get_user_post_paths( $user_id ) );

        /**
         *
         * Filter paths
         * 
         * @var array $page_paths
         *
         * @since 1.0.8
         * 
         */
        return apply_filters( 'streamtube/core/googlesitekit/user/page_paths', $page_paths );
    }
}