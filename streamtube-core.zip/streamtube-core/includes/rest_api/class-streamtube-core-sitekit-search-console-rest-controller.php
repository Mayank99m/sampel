<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define the rest functionality.
 *
 * @since      1.0.8
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 * @author     phpface <nttoanbrvt@gmail.com>
 */
class StreamTube_Core_Google_SiteKit_Search_Console_Rest_Controller extends StreamTube_Core_Google_SiteKit_Rest_Controller{

    protected $path = '/search-console';

    /**
     * @since 1.0.8
     */
    public function rest_api_init(){      

        register_rest_route(
            "{$this->namespace}{$this->version}",
            $this->path . '/searchanalytics',
            array(
                'methods'   =>  WP_REST_Server::READABLE,
                'callback'  =>  array( $this , 'get_reports' ),
                'args'      =>  array(
                    'dimensions'    =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_string( $param ) || is_array( $param );
                        }
                    ),
                    'url' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_string( $param );
                        }
                    ),
                    'start_date' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_string( $param );
                        }
                    ),
                    'end_date' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_string( $param );
                        }
                    ),
                    'page_paths' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_string( $param );
                        }
                    ),
                    'limit' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_int( $param );
                        }
                    )
                ),
                'permission_callback'   =>  function( $request ){
                    return is_user_logged_in();
                }
            )
        );
    }

    public function get_reports( $request ){

        $compare = false;

        $params = array();

        if( ! $request['limit'] ){
            $request['limit'] = 10;
        }

        $params['dimensions'] = $request['dimensions'];

        $date_ranges = $this->get_date_ranges( $request, $compare );

        if( is_wp_error( $date_ranges ) ){
            wp_send_json_error( $date_ranges );
        }        

        $params = array_merge( $params, array(
            'startDate' =>  $date_ranges[0]['startDate'],
            'endDate' =>  $date_ranges[0]['endDate']
        ) );

        $params['url'] = untrailingslashit( get_site_url('/') );

        //$params['_locale'] = 'user';
        $params['includeEmptyRows'] = true;        
        $params['rowLimit'] = $request['limit'];

        $params['aggregationType'] = 'auto';

        $cache_expiration = $this->is_caching();

        if( $cache_expiration ){
            $hash = md5( json_encode( $params ) );

            if( false !== $response = get_transient( $hash ) ){
                wp_send_json_success( array_merge( $response, array(
                    'cached'    =>  true
                ) ) );
            }
        }        

        $response = $this->plugin()->search_console->get_reports( $params );

        if( is_wp_error( $response ) ){
            wp_send_json_error( $response );
        }

        $response = compact( 'response', 'params' );

        if( $cache_expiration ){
            set_transient( $hash, $response, $cache_expiration );    
        }        

        wp_send_json_success( $response );
    }
}