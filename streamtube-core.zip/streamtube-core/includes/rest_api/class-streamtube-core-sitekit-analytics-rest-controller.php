<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define the rest functionality.
 *
 * @since      1.0.8
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 * @author     phpface <nttoanbrvt@gmail.com>
 */
class StreamTube_Core_Google_SiteKit_Analytics_Rest_Controller extends StreamTube_Core_Google_SiteKit_Rest_Controller{

    protected $path = '/analytics';

    /**
     *
     * Get default path
     * 
     * @return string
     *
     * @since 1.0.9
     * 
     */
    public function get_default_path(){
        return apply_filters( 'streamtube/core/rest/analytics/default_path', '/' );
    }

    /**
     * @since 1.0.8
     */
    public function rest_api_init(){      

        register_rest_route(
            "{$this->namespace}{$this->version}",
            $this->path . '/reports/(?P<id>[a-zA-Z0-9-]+)',
            array(
                'methods'   =>  WP_REST_Server::READABLE,
                'callback'  =>  array( $this , 'get_reports' ),
                'args'      =>  array(
                    'id' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_string( $param );
                        }
                    ),
                    'start_date' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_string( $param );
                        }
                    ),
                    'end_date' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_string( $param );
                        }
                    ),              
                    'limit' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_int( $param );
                        }
                    )               
                ),
                'permission_callback'   =>  function( $request ){
                    return is_user_logged_in();
                }
            )
        );

        register_rest_route(
            "{$this->namespace}{$this->version}",
            $this->path . '/pageviews/(?P<id>[\d]+)',
            array(
                'methods'   =>  WP_REST_Server::READABLE,
                'callback'  =>  array( $this , 'get_page_views' ),
                'args'      =>  array(
                    'id' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_numeric( $param );
                        }
                    )
                ),                
                'permission_callback'   =>  function( $request ){
                    return true;
                }
            )
        );

        register_rest_route(
            "{$this->namespace}{$this->version}",
            $this->path . '/videoviews/(?P<id>[\d]+)',
            array(
                'methods'   =>  WP_REST_Server::READABLE,
                'callback'  =>  array( $this , 'get_video_views' ),
                'args'      =>  array(
                    'id' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_numeric( $param );
                        }
                    )
                ),                
                'permission_callback'   =>  function( $request ){
                    return true;
                }
            )
        );

        register_rest_route(
            "{$this->namespace}{$this->version}",
            $this->path . '/totalviews/(?P<id>[\d]+)',
            array(
                'methods'   =>  WP_REST_Server::READABLE,
                'callback'  =>  array( $this , 'get_total_views' ),
                'args'      =>  array(
                    'id' =>  array(
                        'validate_callback' => function( $param, $request, $key ) {
                            return is_numeric( $param );
                        }
                    )
                ),                
                'permission_callback'   =>  function( $request ){
                    return true;
                }
            )
        );
    }

    /**
     *
     * Get overview reports metrics
     * 
     * @since 1.0.8
     * 
     */
    public function get_overview_metrics(){
        $metrics = array(
            'pageviews' =>  array(
                'metric'    =>  'ga:pageViews',
                'alias'     =>  esc_html__( 'Page Views', 'streamtube-core' )
            ),
            'uniquepageviews' =>  array(
                'metric'    =>  'ga:uniquePageViews',
                'alias'     =>  esc_html__( 'Unique Page Views', 'streamtube-core' )
            ),
            'users' =>  array(
                'metric'    =>  'ga:users',
                'alias'     =>  esc_html__( 'Users', 'streamtube-core' )
            ),
            'sessions' =>  array(
                'metric'    =>  'ga:sessions',
                'alias'     =>  esc_html__( 'Sessions', 'streamtube-core' )
            ),
            'bouncerate' =>  array(
                'metric'    =>  'ga:bounceRate',
                'alias'     =>  esc_html__( 'Bounce Rate', 'streamtube-core' )
            ),
            'avgsessionduration' =>  array(
                'metric'    =>  'ga:avgSessionDuration',
                'alias'     =>  esc_html__( 'Session Duration', 'streamtube-core' )
            )
        );

        /**
         * @since 1.0.8
         */
        return apply_filters( 'streamtube/core/googlesitekit/reports/overview_metrics', $metrics );
    }

    /**
     *
     * Pre get overview metrics
     * 
     * @return array
     *
     * @since 1.0.8
     * 
     */
    public function pre_get_overview_metrics(){
        $metrics = $this->get_overview_metrics();

        $enabled_metrics = get_option( 'sitekit_reports_overview_metrics' );

        if( empty( $enabled_metrics ) || ! is_array( $enabled_metrics ) ){
            return $metrics;
        }

        foreach ( $metrics as $key => $value ) {
            if( array_key_exists( $key, $enabled_metrics ) && empty( $enabled_metrics[$key] ) ){
                unset( $metrics[ $key ] );
            }
        }

        return $metrics;
    }

    /**
     *
     * Get overview video play event reports metrics
     * 
     * @since 1.0.8
     * 
     */
    public function get_overview_video_metrics(){
        return array(
            'videoviews' =>  array(
                'metric'    =>  'ga:totalEvents',
                'alias'     =>  esc_html__( 'Video Views', 'streamtube-core' )
            ),
            'uniquevideoviews' =>  array(
                'metric'    =>  'ga:uniqueEvents',
                'alias'     =>  esc_html__( 'Unique Video Views', 'streamtube-core' )
            )
        );
    }

    /**
     *
     * Pre get overview metrics
     * 
     * @return array
     *
     * @since 1.0.8
     * 
     */
    public function pre_get_overview_video_metrics(){
        $metrics = $this->get_overview_video_metrics();

        $enabled_metrics = get_option( 'sitekit_reports_overview_video_metrics' );

        if( ! $enabled_metrics || ! is_array( $enabled_metrics ) ){
            return $metrics;
        }

        foreach ( $metrics as $key => $value ) {
            if( array_key_exists( $key, $enabled_metrics ) && empty( $enabled_metrics[$key] ) ){
                unset( $metrics[ $key ] );
            }
        }

        return $metrics;
    }

    /**
     *
     * Get reports
     * 
     * @param  WP_Rest_Request $request
     * @return JSON
     *
     * @since 1.0.8
     * 
     */
    public function get_reports( $request ){

        $page_paths = $params = $dimensionFilterClauses = array();

        $dimensionFilterClauses = array();
    
        if( ! $request['limit'] ){
            $request['limit'] = 10;
        }

        if( $request['page_paths'] ){
            $page_paths = explode( '|' , $request['page_paths'] );
        }        

        $compare = false;

        $metrics = $this->pre_get_overview_metrics();

        $event_metrics = $this->pre_get_overview_video_metrics();

        switch ( $request['id'] ) {
            case 'overview':

                foreach ( $metrics as $metric ) {
                    $params['metrics'][] = array(
                        'expression'    =>  $metric['metric'],
                        'alias'         =>  $metric['alias']
                    );
                }

                $params['dimensions'][] = array(
                    'name'  =>  'ga:date'
                );

                $params['dimensions'][] = array(
                    'name'  =>  'ga:hostname'
                );
                
                $compare = true;
            break;

            case 'videooverviews':

                foreach ( $event_metrics as $metric ) {
                    $params['metrics'][] = array(
                        'expression'    =>  $metric['metric'],
                        'alias'         =>  $metric['alias']
                    );
                }

                $params['dimensions'][] = array(
                    'name'  =>  'ga:date'
                );

                $dimensionFilterClauses[] = array(
                    'dimensionName' =>  'ga:eventCategory',
                    'expressions'   =>  'Video'
                );

                $dimensionFilterClauses[] = array(
                    'dimensionName' =>  'ga:eventAction',
                    'expressions'   =>  'play'
                );
            
                $compare = true;
            break;

            case 'videoviews':
            case 'uniquevideoviews':

                $params['metrics'][] = array(
                    'expression'    =>  $event_metrics[ $request['id'] ]['metric'],
                    'alias'         =>  $event_metrics[ $request['id'] ]['alias']
                );
                $params['dimensions'][] = array(
                    'name'  =>  'ga:date'
                );        
                
                $dimensionFilterClauses[] = array(
                    'dimensionName' =>  'ga:eventCategory',
                    'expressions'   =>  'Video'
                );

                $dimensionFilterClauses[] = array(
                    'dimensionName' =>  'ga:eventAction',
                    'expressions'   =>  'play'
                );

                $compare = true;
            break;

            case 'users':
            case 'sessions':
            case 'uniquepageviews':
            case 'pageviews':
            case 'bouncerate':
            case 'avgsessionduration':
                $params['metrics'][] = array(
                    'expression'    =>  'ga:' . $request['id'],
                    'alias'         =>  $metrics[ $request['id'] ]['alias']
                );
                $params['dimensions'][] = array(
                    'name'  =>  'ga:date'
                );

                $compare = true;            
            break;

            case 'toppageviews':
                $params['metrics'][] = array(
                    'expression'    =>  'ga:pageViews',
                    'alias'         =>  esc_html__( 'Page Views', 'streamtube-core' )
                );
                $params['metrics'][] = array(
                    'expression'    =>  'ga:uniquePageViews',
                    'alias'         =>  esc_html__( 'Unique Page Views', 'streamtube-core' )
                );
                $params['metrics'][] = array(
                    'expression'    =>  'ga:bounceRate',
                    'alias'         =>  esc_html__( 'Bounce Rate', 'streamtube-core' )
                );                

                $params['dimensions'][] = array(
                    'name'  =>  'ga:pagePath'
                );
                $params['dimensions'][] = array(
                    'name'  =>  'ga:pageTitle'
                );

                $params['orderBys'][] = array(
                    'fieldName' =>  'ga:pageViews',
                    'sortOrder' =>  'DESCENDING'
                );

                $params['pageSize'] = $request['limit'];
            break;

            case 'topchannels':
                $params['metrics'][] = array(
                    'expression'    =>  'ga:users',
                    'alias'         =>  esc_html__( 'Users', 'streamtube-core' )
                );

                $params['metrics'][] = array(
                    'expression'    =>  'ga:newUsers',
                    'alias'         =>  esc_html__( 'New Users', 'streamtube-core' )
                );                

                $params['metrics'][] = array(
                    'expression'    =>  'ga:sessions',
                    'alias'         =>  esc_html__( 'Sessions', 'streamtube-core' )
                );

                $params['dimensions'][] = array(
                    'name'  =>  'ga:channelGrouping'
                );

                $params['orderBys'][] = array(
                    'fieldName' =>  'ga:users',
                    'sortOrder' =>  'DESCENDING'
                ); 

                $params['pageSize'] = $request['limit'];

            break;

            case 'topcountries':
                $params['metrics'][] = array(
                    'expression'    =>  'ga:users',
                    'alias'         =>  esc_html__( 'Users', 'streamtube-core' )
                );
                $params['dimensions'][] = array(
                    'name'  =>  'ga:country'
                );

                $params['orderBys'][] = array(
                    'fieldName' =>  'ga:users',
                    'sortOrder' =>  'DESCENDING'
                );
            break;
        }

        $date_ranges = $this->get_date_ranges( $request, $compare, $request['path_paths'] );

        if( is_wp_error( $date_ranges ) ){
            wp_send_json_error( $date_ranges );
        }        

        $params = array_merge( $params, array(
            'dateRanges'    =>  $date_ranges
        ) );

        if( ! current_user_can( 'administrator' ) ){
            if( ! $page_paths ){
                $dimensionFilterClauses[] = array(
                    'dimensionName' =>  'ga:pagePath',
                    'expressions'   =>  $this->get_user_page_paths(),
                    'operator'      =>  'IN_LIST'
                );
            }
        }

        if( ! $page_paths ){

            $dimensionFilterClauses[] = array(
                'dimensionName' =>  'ga:pagePath',
                'expressions'   =>  $this->get_default_path(),
                'operator'      =>  'BEGINS_WITH'
            );
        }else{
            if( count( $page_paths ) > 1 ){
                $dimensionFilterClauses[] = array(
                    'dimensionName' =>  'ga:pagePath',
                    'expressions'   =>  $page_paths,
                    'operator'      =>  'IN_LIST'
                ); 
            }
            else{
                $dimensionFilterClauses[] = array(
                    'dimensionName' =>  'ga:pagePath',
                    'expressions'   =>  $page_paths,
                    'operator'      =>  'BEGINS_WITH'
                );
            }                 
        }

        $dimensionFilterClauses[] = array(
            'dimensionName' =>  'ga:hostname',
            'expressions'   =>  $_SERVER['SERVER_NAME'],
            'operator'      =>  'EXACT'
        );        

        $params['dimensionFilterClauses'] =  array(
            'operator'  =>  'AND',
            'filters'   =>  $dimensionFilterClauses
        );
  
        $params['includeEmptyRows'] = true;

        $cache_expiration = $this->is_caching();

        if( $cache_expiration ){
            $hash = md5( json_encode( $params ) );

            if( false !== $response = get_transient( $hash ) ){
                wp_send_json_success( array_merge( $response, array(
                    'cached'    =>  true
                ) ) );
            }
        }

        $response = $this->plugin()->analytics->get_reports( array_merge( $params, array(
            'viewId'    =>  $this->plugin()->analytics->get_profile_id()
        ) ) );

        if( is_wp_error( $response )){
            wp_send_json_error( new WP_Error(
                $response->get_error_code(),
                $response->get_error_messages()
            ) );
        }

        $response = compact( 'response', 'params' );

        if( $cache_expiration ){
            set_transient( $hash, $response, $cache_expiration );    
        }        

        wp_send_json_success( $response );
    }

    /**
     *
     * Get page views
     * 
     * @param  WP_Rest_Request $request
     * @return JSON
     *
     * @since 1.0.8
     * 
     */
    public function get_page_views( $request ){

        if( ! $request['id'] ){
            wp_send_json_error( new WP_Error(
                'post_id_not_found',
                esc_html__( 'Post ID was not found', 'streamtube-core' )
            ) );
        }

        $response = $this->plugin()->analytics->get_post_views( array(
            'post_id' => absint( $request['id'] )
        ) );

        if( is_wp_error( $response ) ){
            wp_send_json_error( $response );
        }

        wp_send_json_success( $response );
    }

    /**
     *
     * Get video play events
     * 
     * @param  WP_Rest_Request $request
     * @return JSON
     *
     * @since 1.0.8
     */
    public function get_video_views( $request ){
        if( ! $request['id'] ){
            wp_send_json_error( new WP_Error(
                'post_id_not_found',
                esc_html__( 'Video ID was not found', 'streamtube-core' )
            ) );
        }

        $response = $this->plugin()->analytics->get_video_views( array(
            'post_id' => absint( $request['id'] )
        ) );

        if( is_wp_error( $response ) ){
            wp_send_json_error( $response );
        }

        wp_send_json_success( $response );
    }

    /**
     *
     * Request total pageViews and Events
     * 
     * @return JSON
     *
     * @since 1.0.8
     * 
     */
    public function get_total_views( $request ){

        if( ! $request['id'] || ! get_post( $request['id'] ) ){
            wp_send_json_error( new WP_Error(
                'post_id_not_found',
                esc_html__( 'Post ID was not found', 'streamtube-core' )
            ) );
        }

        $cache_expiration = $this->is_caching();

        if( $cache_expiration > 0 ){

            if( false !== $response = get_transient( 'total_views_' . $request['id'] ) ){
                $response = array_merge( $response, array(
                    'cached'    =>  true
                ) );

                wp_send_json_success( $response );
            }
        }        

        $page_views = $this->plugin()->analytics->get_post_views( array(
            'post_id' => absint( $request['id'] )
        ) );

        $video_views = $this->plugin()->analytics->get_video_views( array(
            'post_id' => absint( $request['id'] )
        ) );

        if( is_wp_error( $page_views ) || is_wp_error( $video_views ) ){
            wp_send_json_error( new WP_Error(
                $page_views->get_error_code(),
                $page_views->get_error_messages()
            ) );
        }

        $response = compact( 'page_views', 'video_views' );

         if( $cache_expiration > 0 ){
            set_transient( 'total_views_' . $request['id'], $response, $cache_expiration );
         }

        wp_send_json_success( $response );
    }
}