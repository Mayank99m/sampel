<?php
if( ! defined('ABSPATH' ) ){
    exit;
}

/**
*
* Get the public template file
* 
* @param  string $file
* @return string file path
*
* @since  1.0.0
* 
*/
function streamtube_core_get_template( $file ){
	return trailingslashit( STREAMTUBE_CORE_PUBLIC ) . $file;
}

/**
*
* load the public template file
* 
* @param  string $file
* @return string file path
*
* @since  1.0.0
* 
*/
function streamtube_core_load_template( $file, $require_once = true, $args = array()  ){

	$_file = streamtube_core_get_template( $file );

	if( file_exists( $_file ) ){
		load_template( $_file, $require_once, $args  );	
	}
}

/**
*
* Generate the form field.
* 
* @param  array  $args
* @return HTML
*
* @since  1.0.0
* 
*/
function streamtube_core_the_field_control( $args = array() ){

	$wrap = $output = $data = '';

	$wrap_class = array();

	$args = wp_parse_args( $args, array(
		'label'			=>	'',
		'label_float'	=>	true,
		'required'		=>	false,
		'type'			=>	'text',
		'id'			=>	'',
		'name'			=>	'',
		'value'			=>	'',
		'options'		=>	array(),
		'current'		=>	'',
		'data'			=>	array(),
		'field_class'	=>	'form-control',
		'wrap_class'	=>	'',
		'spellcheck'	=>	'false',
		'settings'		=>	array(),
		'description'	=>	'',
		'echo'			=>	true
	) );

	if( ! $args['name'] ){
		return $output;
	}

	if( ! $args['id'] ){
		$args['id'] = sanitize_key( $args['name'] );
	}

	if( $args['data'] ){
		foreach ( $args['data'] as $attribute => $value ) {
			if( ! empty( $value ) ){
				$data .= sprintf(
					' %s="%s"',
					sanitize_key( $attribute ),
					esc_attr( $value )
				);
			}
		}
	}

	/**
	 * @since 1.0.9
	 */
	$args = apply_filters( 'streamtube_core_the_field_control_args', $args );

	switch ( $args['type'] ) {
		case 'number':
		case 'text':
		case 'email':
		case 'url':
		case 'search':
		case 'password':
		case 'date':
		case 'time':
		case 'datetime-local':
			$output = sprintf(
				'<input class="%s" %s spellcheck="%s" type="%s" value="%s" name="%s" id="%s" %s>',
				esc_attr( $args['field_class'] ),
				$args['required'] ? ' required' : '',
				esc_attr( $args['spellcheck'] ),
				esc_attr( $args['type'] ),
				esc_attr( $args['value'] ),
				esc_attr( $args['name'] ),
				esc_attr( $args['id'] ),
				$data
			);
		break;

		case 'textarea':
			$output = sprintf(
				'<textarea class="%s" %s spellcheck="%s" name="%s" id="%s" %s>%s</textarea>',
				esc_attr( $args['field_class'] ),
				$args['required'] ? ' required' : '',
				esc_attr( $args['spellcheck'] ),
				esc_attr( $args['name'] ),
				esc_attr( $args['id'] ),
				$data,
				esc_textarea( $args['value'] )
			);			
		break;

		case 'editor':
			$args['label_float'] = false;
			ob_start();

			if( ! array_key_exists( 'settings', $args ) ){
				$args['settings'] = array();
			}

			if( function_exists( 'streamtube_get_theme_mode' ) && streamtube_get_theme_mode() == 'dark' ){
				$args['settings']['tinymce']['content_css'] = trailingslashit( STREAMTUBE_CORE_PUBLIC_URL ) . 'assets/css/editor.css';
			}

			/**
			 *
			 * Filter the editor settings
			 *
			 * @param array $args['settings']
			 *
			 * @since 1.0.8
			 * 
			 */
			$args['settings'] = apply_filters( 'streamtube/core/post/editor_settings', $args['settings'] );

			wp_editor( $args['value'], $args['id'], $args['settings'] );

			$output = ob_get_clean();

		break;

		case 'checkbox':
		case 'radio':
			$args['label_float'] = false;

			if( empty( $args['value'] ) ){
				$args['value'] = 'on';
			}

			$output = sprintf(
				'<input class="form-check-input" %s type="%s" name="%s" id="%s" value="%s" %s %s>',
				$args['required'] ? ' required' : '',
				esc_attr( $args['type'] ),
				esc_attr( $args['name'] ),
				esc_attr( $args['id'] ),
				esc_attr( $args['value'] ),
				checked( $args['current'], $args['value'], false ),
				$data
			);
		break;

		case 'select';
			$output = sprintf(
				'<select class="%s" %s name="%s" id="%s" %s>',
				esc_attr( $args['field_class'] ),
				$args['required'] ? ' required' : '',
				esc_attr( $args['name'] ),
				esc_attr( $args['id'] ),
				$data
			);

				if( is_array( $args['options'] ) ){
					foreach ( $args['options'] as $key => $value ) {
						$output .= sprintf(
							'<option value="%s" %s>%s</option>',
							esc_attr( $key ),
							selected( $args['current'], $key, false ),
							esc_html( $value )
						);
					}
				}

			$output .= '</select>';
		break;
	}

	if( $output ){

		$wrap_class[] = 'mb-3';
		$wrap_class[] = 'field-' . sanitize_html_class( $args['id'] );

		if( $args['wrap_class'] ){
			$wrap_class[] = sanitize_html_class( $args['wrap_class'] );
		}

		if( $args['label_float'] ){
			$wrap_class[] = 'form-floating';
		}

		if( in_array( $args['type'] , array( 'checkbox', 'radio' ) ) ){
			$wrap_class[] = 'form-check';
		}

		$wrap =	 sprintf(
			'<div class="%s">',
			esc_attr( join( ' ', $wrap_class ) )
		);

			if( $args['required'] ){
				$args['label'] .= sprintf(
					'<span class="badge text-danger">%s</span>',
					esc_html__( '(required)', 'streamtube-core' )
				);
			}

			/**
			 *
			 * Filter the field output
			 * 
			 * @var array $args;
			 *
			 * @since  1.0.0
			 * 
			 */
			$wrap .= apply_filters( 'streamtube_core_the_field_control', $output, $args );

			if( $args['label'] && $args['type'] != 'editor' ){
				$wrap .= sprintf(
					'<label class="%s" for="%s">%s</label>',
					in_array( 'form-check', $wrap_class ) ? 'form-check-label' : 'field-label',
					esc_attr( $args['id'] ),
					$args['label']
				);
			}

			if( $args['description'] ){
				$wrap .= sprintf(
					'<div class="description text-muted small mt-2">%s</div>',
					$args['description']
				);
			}

		$wrap .= '</div>';
	}

	/**
	 *
	 * @since 1.0.9
	 * 
	 */
	$wrap = apply_filters( 'streamtube_core_the_field_control', $wrap, $args );

	if( $args['echo'] ){
		echo $wrap;
	}
	else{
		return $wrap;
	}
}


/**
*
* Build a bootstrap class array
*
* 
* @param  array  $args
* @return array
*
* @since  1.0.0
* 
*/
function streamtube_core_build_grid_classes( $args = array() ){
	$classes = array();

	$args = wp_parse_args( $args, array(
		'col_xxl'		=>	3,
		'col_xl'		=>	3,
		'col_lg'		=>	2,
		'col_md'		=>	2,
		'col_sm'		=>	1,
		'col'			=>	1
	) );

	foreach ( $args as $key => $value) {
		if( absint( $value ) == 0 ){
			$value = 1;
		}
		$classes[] = sanitize_html_class( sprintf( '%s-%s', str_replace( "_" , "-", $key ), 12/$value ) );
	}

	/**
	 *
	 * Filter and return the classes
	 *
	 * @param  array  $classes
	 *
	 * @param  array $args
	 *
	 * @since  1.0.0
	 * 
	 */
	return apply_filters( 'streamtube_core_build_grid_classes', $classes, $args );
}

/**
 *
 * Get max upload file size
 * 
 * @return int
 *
 * @since 1.0.0
 * 
 */
function streamtube_core_get_max_upload_size(){

	// Get default allowed size in byte
	$default_max_size = wp_max_upload_size();

	$default_chunk_size = $default_max_size;

	if( class_exists( 'BigFileUploads' ) ){
		$default_chunk_size = (int)get_option( 'tuxbfu_chunk_size' )*1024;
	}

	return min( $default_max_size, $default_chunk_size );
}

/**
 *
 * Convert number to iso8601 duration
 * 
 * @param  string|int $seconds
 * @return string
 *
 * @since 1.0.0
 * 
 */
function streamtube_core_iso8601_duration( $seconds ){

	$seconds = (int)$seconds;

    $days = floor($seconds / 86400);
    $seconds = $seconds % 86400;

    $hours = floor($seconds / 3600);
    $seconds = $seconds % 3600;

    $minutes = floor($seconds / 60);
    $seconds = $seconds % 60;

    return sprintf( 'P%dDT%dH%dM%dS', $days, $hours, $minutes, $seconds);
}

/**
 *
 * Get ratio options
 * 
 * @return array
 *
 * @since 1.0.6
 * 
 */
function streamtube_core_get_ratio_options(){
    $options = array(
        '21x9'  =>  esc_html__( '21x9', 'streamtube-core' ),
        '16x9'  =>  esc_html__( '16x9', 'streamtube-core' ),
        '4x3'   =>  esc_html__( '4x3', 'streamtube-core' ),
        '1x1'   =>  esc_html__( '1x1', 'streamtube-core' )
    );

    return apply_filters( 'streamtube_core_get_options_ratio', $options );
}

/**
 *
 * Format post view count
 * 
 * @param int $int
 * @return string formatted string
 *
 * @since 1.0.8
 * 
 */
function streamtube_core_format_page_views( $int ){
	$formatted = number_format_i18n( $int );

	/**
	*
	* Filter formatted post view
	*
	* @param string $formatted
	* @param int $int
	*
	* @since 1.0.8
	* 
	*/
	return apply_filters( 'streamtube_core_format_page_views', $formatted, $int );
}

/**
 *
 * The login form
 * 
 * @param  array  $args
 * @return [type]       [description]
 */
function streamtube_core_the_login_form( $args = array() ){

	$args = wp_parse_args( $args, array(
		'echo'	=>	true
	) );

	$output = wp_login_form( array_merge( $args, array(
		'echo'	=>	false
	) ) );

	/**
	 *
	 * Filter and output the login form
	 *
	 * @param string $output
	 * @param array $args
	 *
	 * @since 1.1.5
	 * 
	 */
	$output = apply_filters( 'streamtube_core_the_login_form', $output, $args );

	if( $args['echo'] ){
		echo $output;
	}
	else{
		return $output;
	}
}