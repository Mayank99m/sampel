<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://themeforest.net/user/phpface
 * @since      1.0.0
 *
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined('ABSPATH' ) ){
    exit;
}

class Streamtube_Core {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Streamtube_Core_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	protected $plugin_setting_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	protected $plugin;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {

		if ( defined( 'STREAMTUBE_CORE_VERSION' ) ) {
			$this->version = STREAMTUBE_CORE_VERSION;
		} else {
			$this->version = '1.0.0';
		}

		$this->plugin_name = 'streamtube-core';

		$this->plugin = new stdClass();

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->define_core_hooks();
		$this->define_post_hooks();
		$this->define_video_hooks();
		$this->define_comment_hooks();
		$this->define_user_hooks();
		$this->define_woocommerce_hooks();
		$this->define_rest_hooks();

		$this->define_mycred_hooks();

		$this->define_better_messages_hooks();
	}

	/**
	 *
	 * Include file in WP environment
	 * 
	 * @param  string $file
	 *
	 * @since 1.0.9
	 * 
	 */
	private function include_file( $file ){
		require_once trailingslashit( plugin_dir_path( dirname( __FILE__ ) ) ) . $file;
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Streamtube_Core_Loader. Orchestrates the hooks of the plugin.
	 * - Streamtube_Core_i18n. Defines internationalization functionality.
	 * - Streamtube_Core_Admin. Defines all hooks for the admin area.
	 * - Streamtube_Core_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		$this->include_file( 'includes/class-streamtube-core-loader.php' );

		$this->loader = new Streamtube_Core_Loader();

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		$this->include_file( 'includes/class-streamtube-core-i18n.php' );

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		$this->include_file( 'includes/class-streamtube-core-cron.php' );

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		$this->include_file( 'includes/class-streamtube-core-license.php' );		

		$this->plugin->license = new Streamtube_Core_License();

		/**
		 * System permission
		 */
		$this->include_file( 'includes/class-streamtube-core-permission.php' );

		/**
		 * The class responsible for defining oEmbed functionality
		 * of the plugin.
		 */
		$this->include_file( 'includes/class-streamtube-core-oembed.php' );

		/**
		 * The class responsible for defining endpoint functionality
		 * of the plugin.
		 */
		$this->include_file( 'includes/class-streamtube-core-endpoint.php' );	

		/**
		 * The class responsible for defining custom query vars functionality
		 * of the plugin.
		 */
		$this->include_file( 'includes/class-streamtube-core-menu.php' );	

		/**
		 * The class responsible for defining all post functionality
		 */
		$this->include_file( 'includes/class-streamtube-core-post.php' );	

		/**
		 * The class responsible for defining all video functionality
		 */
		$this->include_file( 'includes/class-streamtube-core-video.php' );	

		/**
		 * The class responsible for defining all download functionality
		 */
		$this->include_file( 'includes/class-streamtube-core-download-files.php' );			

		/**
		 * The class responsible for defining all comment functionality
		 */
		$this->include_file( 'includes/class-streamtube-core-comment.php' );	

		/**
		 * The class responsible for defining all custom taxonomies
		 */
		$this->include_file( 'includes/class-streamtube-core-taxonomy.php' );	

		/**
		 * The class responsible for defining sidebar
		 */
		$this->include_file( 'includes/class-streamtube-core-sidebar.php' );	

		/**
		 * The class responsible for defining custom posts widget
		 */
		$this->include_file( 'includes/widgets/class-streamtube-core-widget-posts.php' );	

		/**
		 * The class responsible for defining custom posts widget
		 */
		$this->include_file( 'includes/widgets/class-streamtube-core-widget-comments.php' );	

		/**
		 * The class responsible for defining custom user list widget
		 */
		$this->include_file( 'includes/widgets/class-streamtube-core-widget-user-list.php' );	

		/**
		 * The class responsible for defining custom elementor widgets
		 */
		$this->include_file( 'includes/class-streamtube-core-elementor.php' );		

		/**
		 * The class responsible for defining user profile page
		 */
		$this->include_file( 'includes/class-streamtube-core-user.php' );

		/**
		 * The class responsible for defining user profile page
		 */
		$this->include_file( 'includes/class-streamtube-core-user-profile.php' );	

		/**
		 * The class responsible for defining user profile page
		 */
		$this->include_file( 'includes/class-streamtube-core-user-dashboard.php' );	

		/**
		 * The class responsible for defining shortcodes.
		 */
		$this->include_file( 'includes/class-streamtube-core-shortcode.php' );

		/**
		 * The class responsible for defining restrict conte t
		 */
		$this->include_file( 'includes/class-streamtube-core-restrict-content.php' );	

		$this->plugin->restrict_content = new Streamtube_Core_Restrict_Content();

		/**
		 * The class responsible for defining woocommerce.
		 */
		$this->include_file( 'includes/class-streamtube-core-woocommerce.php' );

		/**
		 * The class responsible for defining Google Sitekit.
		 */
		$this->include_file( 'includes/class-streamtube-core-google-sitekit.php' );

		/**
		 * The class responsible for defining Google Sitekit.
		 */
		$this->include_file( 'includes/class-streamtube-core-google-sitekit-analytics.php' );

		/**
		 * The class responsible for defining Google Sitekit.
		 */
		$this->include_file( 'includes/class-streamtube-core-google-sitekit-tag-manager.php' );

		/**
		 * The class responsible for defining Google Sitekit.
		 */
		$this->include_file( 'includes/class-streamtube-core-google-sitekit-search-console.php' );	

		/**
		 * The class responsible for defining rest.
		 */
		$this->include_file( 'includes/rest_api/class-streamtube-core-rest-api.php' );	

		/**
		 * The class responsible for defining generate image rest API
		 */
		$this->include_file( 'includes/rest_api/class-streamtube-core-generate-image-rest-controller.php' );	

		/**
		 * The class responsible for defining user rest API
		 */
		$this->include_file( 'includes/rest_api/class-streamtube-core-user-rest-controller.php' );	

		/**
		 * The class responsible for defining sitekit rest API
		 */
		$this->include_file( 'includes/rest_api/class-streamtube-core-sitekit-rest-controller.php' );	

		/**
		 * The class responsible for defining analytics rest API
		 */
		$this->include_file( 'includes/rest_api/class-streamtube-core-sitekit-analytics-rest-controller.php' );	

		/**
		 * The class responsible for defining search console rest API
		 */
		$this->include_file( 'includes/rest_api/class-streamtube-core-sitekit-search-console-rest-controller.php' );			

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		$this->include_file( 'admin/class-streamtube-core-admin.php' );	
		
		$this->include_file( 'admin/class-streamtube-core-admin-user.php' );

		$this->include_file( 'admin/class-streamtube-core-admin-post.php' );

		$this->include_file( 'admin/class-streamtube-core-metabox.php' );

		$this->include_file( 'admin/class-streamtube-core-customizer.php' );

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		$this->include_file( 'public/class-streamtube-core-public.php' );	

		/**
		 * The function responsible for defining post functions
		 */		
		$this->include_file( 'includes/function-users.php' );	

		/**
		 * The function responsible for defining post functions
		 */		
		$this->include_file( 'includes/function-posts.php' );	

		/**
		 * The function responsible for defining post functions
		 */		
		$this->include_file( 'includes/function-comments.php' );

		/**
		 * The function responsible for defining user functions
		 */		
		$this->include_file( 'includes/function-templates.php' );

		/**
		 * The function responsible for defining email functions
		 */		
		$this->include_file( 'includes/function-notify.php' );

		/**
		 * The function responsible for defining options functions
		 */		
		$this->include_file( 'includes/function-options.php' );

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Streamtube_Core_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Streamtube_Core_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$this->plugin->customizer = new Streamtube_Core_Customizer();

		$this->loader->add_action(
			'customize_register',
			$this->plugin->customizer,
			'register'
		);	

		$this->plugin->admin = new Streamtube_Core_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 
			'admin_enqueue_scripts', 
			$this->plugin->admin, 
			'enqueue_styles' 
		);
		$this->loader->add_action( 
			'admin_enqueue_scripts', 
			$this->plugin->admin, 
			'enqueue_scripts' 
		);

		$this->plugin->admin_user = new Streamtube_Core_Admin_User();

		$this->loader->add_filter(
			'manage_users_columns',
			$this->plugin->admin_user,
			'user_table',
			10,
			1
		);

		$this->loader->add_filter(
			'manage_users_custom_column',
			$this->plugin->admin_user,
			'user_table_columns',
			10,
			3
		);		

		$this->plugin->admin_post = new Streamtube_Core_Admin_Post();

		$this->loader->add_filter(
			'manage_video_posts_columns',
			$this->plugin->admin_post,
			'post_table',
			10,
			1
		);

		$this->loader->add_action(
			'manage_video_posts_custom_column',
			$this->plugin->admin_post,
			'post_table_columns',
			10,
			2
		);		

		$this->plugin->metabox = new Streamtube_Core_MetaBox();

		$this->loader->add_action( 
			'add_meta_boxes', 
			$this->plugin->metabox, 
			'add_meta_boxes' 
		);

		$this->loader->add_action( 
			'save_post', 
			$this->plugin->metabox, 
			'video_data_save',
			10,
			1 
		);

		$this->loader->add_action(
			'add_meta_boxes', 
			$this->plugin->restrict_content, 
			'metaboxes' 
		);

		$this->loader->add_action( 
			'save_post', 
			$this->plugin->restrict_content, 
			'save_data',
			10,
			1 
		);

		$this->loader->add_action( 
			'streamtube/player/file/output', 
			$this->plugin->restrict_content, 
			'filter_player',
			200,
			1 
		);

		$this->loader->add_action( 
			'streamtube/player/embed/output', 
			$this->plugin->restrict_content, 
			'filter_player',
			200,
			1 
		);

		$this->loader->add_action( 
			'wp_ajax_join_us', 
			$this->plugin->restrict_content, 
			'ajax_request_join_us',
			10,
			1 
		);

		$this->loader->add_action( 
			'wp_footer', 
			$this->plugin->restrict_content, 
			'load_modal_join_us',
			10,
			1 
		);		
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$this->plugin->public = new Streamtube_Core_Public();

		$this->loader->add_action(
			 'wp_enqueue_scripts', 
			 $this->plugin->public, 
			 'enqueue_styles' 
		);

		$this->loader->add_action( 
			'wp_enqueue_scripts', 
			$this->plugin->public, 
			'enqueue_scripts' 
		);

		$this->loader->add_action( 
			'login_enqueue_scripts', 
			$this->plugin->public, 
			'enqueue_scripts' 
		);

		$this->loader->add_action( 
			'enqueue_embed_scripts', 
			$this->plugin->public, 
			'enqueue_embed_scripts' 
		);		

		$this->loader->add_action( 
			'streamtube/header/profile/before', 
			$this->plugin->public,
			'the_upload_button'
		);		

		$this->loader->add_action( 
			'wp_footer', 
			$this->plugin->public, 
			'load_modals' 
		);

		$this->loader->add_filter( 
			'search_template', 
			$this->plugin->public, 
			'load_search_template' 
		);

		$this->loader->add_action(
			'wp_head',
			$this,
			'generator'
		);

	}

	/**
	 * Register all of the hooks related to the core functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_core_hooks(){

		$this->plugin->cron = new Streamtube_Core_Cron();

		$this->loader->add_filter(
			'cron_schedules',
			$this->plugin->cron,
			'add_schedules',
			10,
			1
		);	

		$this->loader->add_action( 
			'init', 
			'Streamtube_Core_Endpoint', 
			'add_endpoints' 
		);

		$this->plugin->taxonomy = new Streamtube_Core_Taxonomy();

		$this->loader->add_action( 
			'init', 
			$this->plugin->taxonomy, 
			'video_category' 
		);

		$this->loader->add_action( 
			'init', 
			$this->plugin->taxonomy, 
			'video_tag' 
		);

		$this->plugin->sidebar = new Streamtube_Core_Sidebar();

		$this->loader->add_action( 
			'widgets_init', 
			$this->plugin->sidebar, 
			'widgets_init'
		);

		$this->loader->add_action( 
			'widgets_init', 
			'Streamtube_Core_Widget_User_List', 
			'register'
		);		

		$this->loader->add_action( 
			'widgets_init', 
			'Streamtube_Core_Widget_Posts', 
			'register'
		);

		$this->loader->add_action( 
			'widgets_init', 
			'Streamtube_Core_Widget_Comments', 
			'register'
		);

		$this->loader->add_action( 
			'wp_ajax_nopriv_widget_load_more_posts', 
			'Streamtube_Core_Widget_Posts', 
			'ajax_load_more_posts' 
		);

		$this->loader->add_action( 
			'wp_ajax_widget_load_more_posts', 
			'Streamtube_Core_Widget_Posts', 
			'ajax_load_more_posts' 
		);

		/** Elementor  */
		$this->plugin->elementor = new Streamtube_Core_Elementor();

		$this->loader->add_action(
			'init',
			$this->plugin->elementor,
			'init'
		);

		$this->plugin->shortcode = new Streamtube_Core_ShortCode();

		$this->loader->add_action( 
			'init', 
			$this->plugin->shortcode, 
			'user_name' 
		);

		$this->loader->add_action(
			'init', 
			$this->plugin->shortcode, 
			'user_avatar' 
		);	

		$this->loader->add_action(
			'init', 
			$this->plugin->shortcode, 
			'user_grid' 
		);

		$this->loader->add_action(
			'wp_ajax_load_more_users',
			$this->plugin->shortcode, 
			'ajax_load_more_users'
		);

		$this->loader->add_action(
			'wp_ajax_nopriv_load_more_users',
			$this->plugin->shortcode, 
			'ajax_load_more_users'
		);

		$this->loader->add_action(
			'init', 
			$this->plugin->shortcode, 
			'post_grid' 
		);

		$this->loader->add_action(
			'init', 
			$this->plugin->shortcode, 
			'playlist' 
		);

		$this->loader->add_action(
			'init', 
			$this->plugin->shortcode, 
			'player' 
		);		

		$this->plugin->oembed = new Streamtube_Core_oEmbed();

		$this->loader->add_action(
			'init', 
			$this->plugin->oembed, 
			'add_providers' 
		);

		$this->plugin->analytics = new Streamtube_Core_Google_SiteKit_Analytics();

		$this->loader->add_action(
			'streamtube_check_pageviews',
			$this->plugin->analytics,
			'cron_update_post_list_pageviews',
			10
		);

		$this->loader->add_action(
			'streamtube_check_videoviews',
			$this->plugin->analytics,
			'cron_update_post_list_videoviews',
			10
		);	


		$this->loader->add_filter(
			'heartbeat_send',
			$this->plugin->analytics,
			'heartbeat_tick',
			10,
			2
		);			

		$this->plugin->search_console = new Streamtube_Core_Google_SiteKit_Search_Console();

		$this->plugin->tag_manager = new Streamtube_Core_Google_SiteKit_Tag_Manager();
	}

	/**
	 * Register all of the hooks related to the post functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_post_hooks(){
		$this->plugin->post = new Streamtube_Core_Post();

		$this->loader->add_action( 
			'init', 
			$this->plugin->post, 
			'cpt_video'
		);		

		$this->loader->add_action( 
			'init', 
			$this->plugin->post, 
			'new_post_statuses'
		);		

		$this->loader->add_action( 
			'streamtube/core/post/update', 
			$this->plugin->post, 
			'update_post_meta'
		);


		$this->loader->add_action( 
			'wp_ajax_add_post', 
			$this->plugin->post, 
			'ajax_add_post'
		);

		$this->loader->add_action( 
			'wp_ajax_import_embed', 
			$this->plugin->post, 
			'ajax_import_embed'
		);

		$this->loader->add_action( 
			'wp_ajax_add_video', 
			$this->plugin->post, 
			'ajax_add_video'
		);
		
		$this->loader->add_action( 
			'wp_ajax_upload_video', 
			$this->plugin->post, 
			'ajax_upload_video'
		);

		$this->loader->add_action(
			'wp_ajax_upload_video_chunk',
			$this->plugin->post, 
			'ajax_upload_video_chunk'
		);			

		$this->loader->add_action( 
			'wp_ajax_upload_video_chunks', 
			$this->plugin->post, 
			'ajax_upload_video_chunks'
		);		

		$this->loader->add_action( 
			'wp_ajax_update_post', 
			$this->plugin->post, 
			'ajax_update_post'
		);		

		$this->loader->add_action( 
			'wp_ajax_trash_post', 
			$this->plugin->post, 
			'ajax_trash_post'
		);

		$this->loader->add_action( 
			'wp_ajax_approve_post', 
			$this->plugin->post, 
			'ajax_approve_post'
		);

		$this->loader->add_action( 
			'wp_ajax_reject_post', 
			$this->plugin->post, 
			'ajax_reject_post'
		);

		$this->loader->add_action( 
			'wp_ajax_restore_post', 
			$this->plugin->post, 
			'ajax_restore_post'
		);

		$this->loader->add_action( 
			'streamtube/core/post/edit/metaboxes', 
			$this->plugin->post, 
			'load_thumbnail_metabox',
			10
		);

		$this->loader->add_action( 
			'streamtube/core/post/edit/metaboxes', 
			$this->plugin->post, 
			'load_taxonomies_metabox',
			50
		);		

		$this->loader->add_action( 
			'template_redirect', 
			$this->plugin->post, 
			'load_edit_template'
		);

		$this->loader->add_action( 
			'wp', 
			$this->plugin->post, 
			'redirect_to_edit_page'
		);

		$this->loader->add_action( 
			'pre_get_posts', 
			$this->plugin->post, 
			'pre_get_posts',
			10,
			1
		);

		$this->loader->add_action( 
			'wp_head', 
			$this->plugin->post, 
			'load_video_schema',
			1
		);

		$this->loader->add_action( 
			'ajax_query_attachments_args', 
			$this->plugin->post, 
			'filter_ajax_query_attachments_args',
			10,
			1
		);

		$this->loader->add_action( 
			'wp_insert_post', 
			$this->plugin->post, 
			'wp_insert_post',
			10,
			3
		);		

		$this->loader->add_action( 
			'wp', 
			$this->plugin->post, 
			'update_last_seen'
		);

		$this->loader->add_action( 
			'before_delete_post', 
			$this->plugin->post, 
			'delete_attached_files',
			10,
			2
		);

		$this->loader->add_action( 
			'delete_attachment', 
			$this->plugin->post, 
			'delete_attached_files',
			10,
			2
		);

		$this->loader->add_action( 
			'template_redirect', 
			$this->plugin->post, 
			'attachment_template_redirect',
			10,
			1
		);	

		$this->loader->add_filter( 
			'wp_video_shortcode', 
			$this->plugin->post, 
			'override_wp_video_shortcode',
			100,
			4
		);

		$this->loader->add_filter( 
			'render_block', 
			$this->plugin->post, 
			'override_wp_video_block',
			100,
			2
		);

		$this->loader->add_filter( 
			'render_block', 
			$this->plugin->post, 
			'override_wp_youtube_block',
			100,
			2
		);			
	}

	/**
	 * Register all of the hooks related to the video functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_video_hooks(){
		$this->plugin->video = new Streamtube_Core_Video();

		$this->loader->add_action(
			'post_embed_url',
			$this->plugin->video,
			'filer_embed_url',
			100,
			2
		);			

		$this->loader->add_action(
			'embed_html',
			$this->plugin->video,
			'filter_embed_html',
			100,
			4
		);		

		$this->loader->add_action(
			'streamtube/single/video/control',
			$this->plugin->video,
			'load_button_share',
			100
		);

		$this->loader->add_action(
			'wp_footer',
			$this->plugin->video,
			'load_modal_share'
		);

		$this->loader->add_action(
			'streamtube/single/video/meta',
			$this->plugin->video,
			'load_single_post_date'
		);

		$this->loader->add_action(
			'streamtube/single/video/meta',
			$this->plugin->video,
			'load_single_post_views'
		);

		$this->loader->add_action(
			'streamtube/single/video/meta',
			$this->plugin->video,
			'load_single_post_comment_count'
		);

		$this->loader->add_action(
			'streamtube/single/video/meta',
			$this->plugin->video,
			'load_single_post_terms'
		);

		$this->loader->add_action(
			'streamtube/single/video/control',
			$this->plugin->video,
			'load_single_post_analytics_button',
			100
		);

		$this->plugin->download_file = new StreamTube_Core_Download_File();

		$this->loader->add_action( 
			'streamtube/single/video/control', 
			$this->plugin->download_file,
			'button_download',
			5
		);

		$this->loader->add_action( 
			'template_redirect', 
			$this->plugin->download_file,
			'process_download'
		);

	}

	/**
	 * Register all of the hooks related to the comment functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_comment_hooks(){
		$this->plugin->comment = new Streamtube_Core_Comment();

		$this->loader->add_action(
			'wp_ajax_nopriv_post_comment',
			$this->plugin->comment, 
			'ajax_post_comment'
		);		

		$this->loader->add_action(
			'wp_ajax_post_comment',
			$this->plugin->comment, 
			'ajax_post_comment'
		);

		$this->loader->add_action(
			'wp_ajax_get_comment',
			$this->plugin->comment, 
			'ajax_get_comment'
		);		

		$this->loader->add_action(
			'wp_ajax_edit_comment',
			$this->plugin->comment, 
			'ajax_edit_comment'
		);		

		$this->loader->add_action(
			'wp_ajax_moderate_comment',
			$this->plugin->comment, 
			'ajax_moderate_comment'
		);

		$this->loader->add_action(
			'wp_ajax_trash_comment',
			$this->plugin->comment, 
			'ajax_trash_comment'
		);

		$this->loader->add_action(
			'wp_ajax_spam_comment',
			$this->plugin->comment, 
			'ajax_spam_comment'
		);		

		$this->loader->add_action(
			'wp_ajax_load_more_comments',
			$this->plugin->comment, 
			'ajax_load_more_comments'
		);

		$this->loader->add_action(
			'wp_ajax_nopriv_load_more_comments',
			$this->plugin->comment, 
			'ajax_load_more_comments'
		);	

		$this->loader->add_action(
			'wp_ajax_load_comments',
			$this->plugin->comment, 
			'ajax_load_comments'
		);

		$this->loader->add_action(
			'wp_ajax_nopriv_load_comments',
			$this->plugin->comment, 
			'ajax_load_comments'
		);		

		$this->loader->add_filter(
			'streamtube/comment/form_args',
			$this->plugin->comment, 
			'filter_comment_form_args'
		);		

		$this->loader->add_filter(
			'comments_template',
			$this->plugin->comment, 
			'load_ajax_comments_template'
		);
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_user_hooks(){

		$this->plugin->user = new Streamtube_Core_User();

		$this->loader->add_action( 
			'get_avatar_data', 
			$this->plugin->user, 
			'get_avatar_data',
			10,
			3 
		);

		$this->loader->add_action( 
			'pre_get_posts', 
			$this->plugin->user, 
			'pre_get_posts' 
		);

		$this->plugin->user_profile = new Streamtube_Core_User_Profile();

		$this->loader->add_action( 
			'init', 
			$this->plugin->user_profile, 
			'add_endpoints', 
			100
		);

		$this->loader->add_action( 
			'streamtube/core/user/header', 
			$this->plugin->user_profile, 
			'the_header', 
			10 
		);

		$this->loader->add_action( 
			'streamtube/core/user/header', 
			$this->plugin->user_profile, 
			'the_navigation', 20 
		);

		$this->loader->add_action( 
			'streamtube/core/user/main', 
			$this->plugin->user_profile, 
			'the_main' 
		);

		$this->loader->add_action( 
			'template_redirect', 
			$this->plugin->user_profile, 
			'the_index',
			20
		);

		$this->loader->add_action( 
			'streamtube/core/user/profile/about/bio', 
			$this->plugin->user_profile, 
			'format_user_bio_content',
			10,
			1
		);		

		$this->plugin->user_dashboard = new Streamtube_Core_User_Dashboard();

		$this->loader->add_action( 
			'init', 
			$this->plugin->user_dashboard, 
			'add_endpoints'
		);		

		$this->loader->add_action( 
			'template_redirect', 
			$this->plugin->user_dashboard, 
			'the_index',
			15
		);

		$this->loader->add_action( 
			'streamtube/user/dashboard/before', 
			$this->plugin->user_dashboard, 
			'the_sitekit_reports'
		);

		$this->loader->add_action( 
			'login_redirect', 
			$this->plugin->user_dashboard, 
			'login_redirect',
			10,
			3
		);
	}

	/**
	 *
	 * Define woocommerce hooks
	 * 
	 * @since 1.0.0
	 */
	private function define_woocommerce_hooks(){

		$this->plugin->woocommerce = new Streamtube_Core_Woocommerce();

		$this->loader->add_action(
			'init',
			$this->plugin->woocommerce,
			'remove_default'
		);

		$this->loader->add_action(
			'wp_ajax_get_cart_total',
			$this->plugin->woocommerce,
			'ajax_get_cart'
		);

		$this->loader->add_action(
			'wp_ajax_nopriv_get_cart_total',
			$this->plugin->woocommerce,
			'ajax_get_cart'
		);		
	}

	/**
	 *
	 * Define rest hooks
	 * 
	 * @since 1.0.0
	 */
	private function define_rest_hooks(){

		$this->plugin->rest_api = array();

		$this->plugin->rest_api['generate_image'] 	= new StreamTube_Core_Generate_Image_Rest_Controller();
		$this->plugin->rest_api['user'] 			= new StreamTube_Core_User_Rest_Controller();
		$this->plugin->rest_api['analytics'] 		= new StreamTube_Core_Google_SiteKit_Analytics_Rest_Controller();
		$this->plugin->rest_api['search_console'] 	= new StreamTube_Core_Google_SiteKit_Search_Console_Rest_Controller();

		foreach (  $this->plugin->rest_api as $rest => $object ) {
			$this->loader->add_action( 
				'rest_api_init',
				$object,
				'rest_api_init'
			);
		}
	}

	/**
	 *
	 * myCred Hooks
	 * 
	 * @since 1.0.9
	 */
	private function define_mycred_hooks(){
		/**
		 * The class responsible for defining myCred functions
		 */
		$this->include_file( 'third-party/mycred/class-streamtube-core-mycred.php' );

		$this->plugin->myCRED = new Streamtube_Core_myCRED();

		if( $this->plugin->myCRED->is_activated() ){
			$this->loader->add_action(
				'mycred_log_row_classes',
				$this->plugin->myCRED,
				'filter_log_row_classes',
				10,
				2
			);

			$this->loader->add_action(
				'mycred_log_username',
				$this->plugin->myCRED,
				'filter_mycred_log_username',
				10,
				3
			);			

			$this->loader->add_action(
				'streamtube/user/profile_dropdown/avatar/after',
				$this->plugin->myCRED,
				'show_user_dropdown_profile_balance'
			);

			$this->loader->add_filter(
				'streamtube/core/user/dashboard/menu/items',
				$this->plugin->myCRED,
				'add_dashboard_menu',
				10,
				1
			);			

			$this->loader->add_action(
				'streamtube/core/elementor/widgets_registered',
				$this->plugin->myCRED,
				'widgets_registered',
				10,
				1
			);	

			$this->loader->add_action(
				'wp',
				$this->plugin->myCRED,
				'redirect_buy_points_page'			
			);			

			$this->loader->add_filter(
				'mycred_buycred_checkout_cancel',
				$this->plugin->myCRED,
				'filter_cancel_checkout',
				10,
				1				
			);

			$this->loader->add_filter(
				'streamtube/player/file/setup',
				$this->plugin->myCRED->sell_content,
				'filter_player_setup',
				100,
				2				
			);			

			$this->loader->add_filter(
				'streamtube/player/file/output',
				$this->plugin->myCRED->sell_content,
				'filter_player',
				300,
				1				
			);

			$this->loader->add_filter(
				'streamtube/player/embed/output',
				$this->plugin->myCRED->sell_content,
				'filter_player',
				300,
				1				
			);			

			$this->loader->add_action(
				'streamtube/core/post/updated',
				$this->plugin->myCRED->sell_content,
				'update_price',
				10,
				1
			);

			$this->loader->add_action(
				'streamtube/core/post/edit/metaboxes',
				$this->plugin->myCRED->sell_content,
				'load_metabox_price',
				20,
				1
			);

			$this->loader->add_action(
				'wp_ajax_nopriv_transfers_points',
				$this->plugin->myCRED->transfers,
				'ajax_transfers_points',
				10
			);
			$this->loader->add_action(
				'wp_ajax_transfers_points',
				$this->plugin->myCRED->transfers,
				'ajax_transfers_points',
				10
			);

			$this->loader->add_action(
				'streamtube/authorbox/avatar/after',
				$this->plugin->myCRED->transfers,
				'button_donate',
				10		
			);

			$this->loader->add_action(
				'streamtube/core/user/navigation/right',
				$this->plugin->myCRED->transfers,
				'button_donate',
				10
			);

			$this->loader->add_action(
				'wp_footer',
				$this->plugin->myCRED->transfers,
				'modal_donate',
				10
			);			

			$this->loader->add_action(
				'mycred_pre_process_cashcred',
				$this->plugin->myCRED->cash_cred,
				'fix_withdrawal_404'
			);

		}
	}

	/**
	 *
	 * Better Messages Hooks
	 * 
	 * @since 1.1.3
	 */
	private function define_better_messages_hooks(){
		$this->include_file( 'third-party/better-messages/class-streamtube-core-better-messages.php' );

		$this->plugin->better_messages = new StreamTube_Core_Better_Messages();

		if( $this->plugin->better_messages->is_activated() ){

			$this->loader->add_action(
				'wp_ajax_get_recipient_info',
				$this->plugin->better_messages,
				'get_recipient_info'
			);

			$this->loader->add_action(
				'wp_ajax_nopriv_get_recipient_info',
				$this->plugin->better_messages,
				'get_recipient_info'
			);

			$this->loader->add_action(
				'streamtube/avatar_dropdown/after',
				$this->plugin->better_messages,
				'show_unread_threads_badge_on_avatar'
			);			

			$this->loader->add_filter(
				'streamtube/core/user/profile/menu/items',
				$this->plugin->better_messages,
				'add_profile_menu',
				10,
				1
			);			

			$this->loader->add_filter(
				'streamtube/core/user/dashboard/menu/items',
				$this->plugin->better_messages,
				'add_dashboard_menu',
				10,
				1
			);

			$this->loader->add_action(
				'streamtube/core/user/navigation/right',
				$this->plugin->better_messages,
				'button_private_message',
				20
			);

			$this->loader->add_action(
				'streamtube/single/video/author/after',
				$this->plugin->better_messages,
				'button_private_message',
				20
			);

			$this->loader->add_action(
				'streamtube/core/user/card/name/after',
				$this->plugin->better_messages,
				'user_list_button_private_message',
				20
			);

			$this->loader->add_action(
				'wp_footer',
				$this->plugin->better_messages,
				'modal_private_message',
				10
			);	

			$this->loader->add_action(
				'wp',
				$this->plugin->better_messages,
				'goto_inbox',
				10
			);
		}
	}

	/**
	 *
	 * Generator meta tag
	 * 
	 * @since 1.0.8
	 */
	public function generator(){

		printf(
			'<meta name="generator" content="%1$s | %2$s | %3$s">',
			'StreamTube',
			'Video Streaming WordPress Theme',
			'https://1.envato.market/qny3O5'
		);
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get() {
		return $this->plugin;
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Streamtube_Core_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
