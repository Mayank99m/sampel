<?php
if( ! defined('ABSPATH' ) ){
    exit;
}

/**
 *
 * Notify author on post approve event
 *
 * @param  int $post_id
 * @param string $personal_message
 * @return wp_mail()
 *
 * @since  1.0.0
 * 
 */
function streamtube_core_notify_author_on_post_approve( $post_id = 0, $personal_message = '' ){

	if( ! $post_id || get_post_status( $post_id ) != 'publish' ){
		return false;
	}

	$post 				= get_post( $post_id );
	$author_data 		= get_userdata( $post->post_author );

	$email 				= array();

	$email['to']		= $author_data->user_email;

	$email['subject']	= sprintf(
		esc_html__( 'Your %s has been approved', 'streamtube-core' ),
		$post->post_type
	);

	$email['message']	= sprintf(
		esc_html__( 'Congratulations! Your %s %s has been approved', 'streamtube-core' ),
		$post->post_type,	
		$post->post_title
	) . "\r\n";

	if( $personal_message ){
		$email['message']	= $personal_message;
	}

	$email['message']	.= get_permalink( $post_id ) . "\r\n";

	$email['headers'] 	= array( 'Content-Type: text/plain; charset="' . get_option( 'blog_charset' ) );

	/**
	 *
	 * Filter the email before send
	 *
	 * @param  array $email
	 * @param  int $post_id
	 * @param  string $message
	 *
	 * @since  1.0.0
	 * 
	 */
	$email = apply_filters(  'streamtube_core_notify_author_on_post_approve_email' , $email , $post_id, $personal_message );

	extract( $email );

	wp_mail( $to, $subject, $message, $headers );
}

/**
 *
 * Notify author on post reject event
 *
 * @param  int $post_id
 * @param string $personal_message
 * @return wp_mail()
 *
 * @since  1.0.0
 * 
 */
function streamtube_core_notify_author_on_post_reject( $post_id = 0, $personal_message = '' ){

	if( ! $post_id || get_post_status( $post_id ) != 'reject' ){
		return false;
	}

	$post 				= get_post( $post_id );
	$author_data 		= get_userdata( $post->post_author );

	$email 				= array();

	$email['to']		= $author_data->user_email;

	$email['subject']	= sprintf(
		esc_html__( 'Your %s has been rejected', 'streamtube-core' ),
		$post->post_type
	);

	$email['message']	= sprintf(
		esc_html__( 'Sorry! Your %s %s has been rejected', 'streamtube-core' ),
		$post->post_type,	
		$post->post_title
	) . "\r\n";

	if( $personal_message ){
		$email['message']	= $personal_message;
	}

	$email['message']	.= get_permalink( $post_id ) . "\r\n";

	$email['headers'] 	= array( 'Content-Type: text/plain; charset="' . get_option( 'blog_charset' ) );

	/**
	 *
	 * Filter the email before send
	 *
	 * @param  array $email
	 * @param  int $post_id
	 * @param  string $message
	 *
	 * @since  1.0.0
	 * 
	 */
	$email = apply_filters(  'streamtube_core_notify_author_on_post_reject_email' , $email , $post_id, $personal_message );

	extract( $email );

	wp_mail( $to, $subject, $message, $headers );
}