<?php
/**
 * Define the Permission functionality
 *
 *
 * @link       https://themeforest.net/user/phpface
 * @since      1.0.0
 *
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 */

/**
 *
 * @since      1.0.0
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 * @author     phpface <nttoanbrvt@gmail.com>
 */

if( ! defined('ABSPATH' ) ){
    exit;
}

class Streamtube_Core_Permission{

    /**
     *
     * Check if current user can moderate posts
     * 
     * @return [type] [description]
     */
    public static function moderate_posts(){

        if( current_user_can( 'administrator' ) || current_user_can( 'editor' ) ){
            return true;
        }

        return false;
    }

}