<?php
/**
 * Define the Google Analytics Report functionality
 *
 *
 * @link       https://themeforest.net/user/phpface
 * @since      1.0.0
 *
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 */

/**
 * Define the analytics functionality
 *
 * @since      1.0.8
 * @package    Streamtube_Core
 * @subpackage Streamtube_Core/includes
 * @author     phpface <nttoanbrvt@gmail.com>
 */

if( ! defined('ABSPATH' ) ){
    exit;
}

class Streamtube_Core_Google_SiteKit_Analytics extends Streamtube_Core_Google_SiteKit{

    protected $endpoint = 'https://analyticsreporting.googleapis.com/v4/reports:batchGet';

    /**
     *
     * Holds the module slug
     * 
     * @var string
     *
     * @since 1.0.8
     * 
     */
    protected $module = 'analytics';

    /**
     *
     * Holds the datapoint slug
     * 
     * @var string
     *
     * @since 1.0.8
     * 
     */    
    protected $datapoint    = 'report';

    /**
     *
     * Posts per page
     * 
     * @return int
     *
     * @since 1.0.8
     * 
     */
    public function get_cron_posts_per_page(){
        return apply_filters( 'streamtube/cron_posts_per_page', 100 );
    }

    /**
     *
     * Check if Google Sitekit Analytics module activated
     * 
     * @return true|false
     *
     * @since 1.0.8
     * 
     */
    public function is_connected(){
        return $this->is_module_active();
    }

    /**
     *
     * Check if module is active
     * 
     * @return boolean
     *
     * @since 1.0.8
     * 
     */
    public function is_active(){

        $is_connected = $this->is_connected();

        $is_enabled = get_option( 'sitekit_reports', 'on' );

        if( ! $is_connected || ! $is_enabled ){
            return false;
        }

        if( current_user_can( 'administrator' ) ){
            // Always return true if current logged in is admin.
            return true;
        }

        $limit_cap = get_option( 'sitekit_reports_cap' );

        if( ! empty( $limit_cap ) && ! current_user_can( $limit_cap ) ){
            return false;
        }

        /**
         *
         * Filter the is_connected() results
         * 
         */
        return apply_filters( "streamtube/core/googlesitekit/{$this->module}/active", true );
    }

    /**
     *
     * Get Analytics profile ID
     * 
     * @return false|string
     *
     * @since 1.0.9
     * 
     */
    public function get_profile_id(){

        if( ! $this->is_connected() ){
            return false;
        }

        global $wpdb;

        $results = $wpdb->get_row(  "SELECT * FROM {$wpdb->options} WHERE `option_name` = 'googlesitekit_analytics_settings' " );     

        if( ! $results ){
            return false;
        }   

        $settings = unserialize( $results->option_value );

        if( ! $settings || ! is_array( $settings ) || ! array_key_exists( 'profileID', $settings ) ){
            return false;
        }

        return $settings['profileID'];
    }

    /**
     *
     * Get start dates
     * 
     * @return array
     *
     * @since 1.0.8
     * 
     */
    public function get_start_dates(){
        $date_ranges = array(
            'today'         =>  esc_html__( 'Today', 'streamtube-core' ),
            'yesterday'     =>  esc_html__( 'Yesterday', 'streamtube-core' ),
            '7daysAgo'      =>  esc_html__( 'Last 7 days', 'streamtube-core' ),
            '14daysAgo'     =>  esc_html__( 'Last 14 days', 'streamtube-core' ),
            '28daysAgo'     =>  esc_html__( 'Last 28 days', 'streamtube-core' ),
            '90daysAgo'     =>  esc_html__( 'Last 90 days', 'streamtube-core' ),
            '180daysAgo'    =>  esc_html__( 'Last 180 days', 'streamtube-core' ),
        );  

        return apply_filters( 'streamtube/core/analytics/start_dates', $date_ranges );
    }

    /**
     *
     * Get tabs
     * 
     * @return array
     *
     * @since 1.0.8
     * 
     */
    public function get_tabs(){
        return array(
            'users'             =>  esc_html__( 'Users', 'streamtube-core' ),
            'sessions'          =>  esc_html__( 'Sessions', 'streamtube-core' ),
            'bounce_rate'       =>  esc_html__( 'Bounce Rate', 'streamtube-core' ),
            'session_duration'  =>  esc_html__( 'Session Duration', 'streamtube-core' )
        );
    }

    /**
     *
     * Check if given post if exists
     * 
     * @param  integer $post_id
     * @return $post_id or WP_Error
     *
     * @since 1.0.8
     * 
     */
    private function is_exist_post( $post_id = 0 ){

        $post = get_post( $post_id );

        if( ! $post ){
            return new WP_Error(
                'invalid_post',
                esc_html__( 'Invalid Post', 'streamtube-core' )
            );
        }        

        return $post;
    }

    /**
     *
     * Get post path
     * 
     * @param  int $post_id
     * @return string
     */
    private function get_post_path( $post_id = 0 ){
        $path = str_replace( home_url( '/' ), '/', get_permalink( $post_id ) );

        return apply_filters( 'streamtube/core/page/path', $path, $post_id );
    }

    /**
     *
     * Get page view by post Id or page Path
     * 
     * @param  array $args
     * @return int|WP_Error
     *
     * @since 1.0.8
     * 
     */
    public function get_post_views( $args = array() ){

        $params = array();

        $args = wp_parse_args( $args, array(
            'post_id'   =>  0,
            'pagePath'  =>  '',
            'startDate' =>  '',
            'endDate'   =>  'today'
        ) );

        extract( $args );

        if( empty( $args['pagePath'] ) ){
            $post = $this->is_exist_post( $post_id );

            if( is_wp_error( $post )){
                return $post;
            }

            $args['pagePath'] = $this->get_post_path( $post->ID ); 

            if( empty( $startDate ) ){
                $startDate = date( 'Y-m-d', strtotime( $post->post_date ) );
            }
        }

        $params['metrics'][] = array(
            'expression'        =>  'ga:pageViews',
            'alias'             =>  esc_html__( 'Page Views', 'streamtube-core' )
        );

        $params['metrics'][] = array(
            'expression'        =>  'ga:uniquePageViews',
            'alias'             =>  esc_html__( 'Unique Page Views', 'streamtube-core' )
        );

        $params['dimensions'][] = array(
            'name'  =>  'ga:pagePath'
        );

        $params['dimensions'][] = array(
            'name'  =>  'ga:pageTitle'
        );

        $params['dimensionFilters']['ga:pagePath'][] = $args['pagePath'];

        $params = array_merge( $params, array(
            'startDate' =>  $startDate,
            'endDate'   =>  $endDate
        ) );        

        $response = $this->call_api( $params );

        if( is_wp_error( $response ) ){
            return $response;
        }

        $response = $response[0]['data']['totals'][0]['values'];

        update_post_meta( $post_id, '_pageviews', $response[0] );
        update_post_meta( $post_id, '_uniquepageviews', $response[1] );

        return compact( 'response', 'params', 'args' );
    }

    /**
     *
     * Get video views by Play event
     * 
     * @param  array  $args
     * @return array|WP_Error
     *
     * @since 1.0.8
     * 
     */
    public function get_video_views( $args = array() ){
        $params = array();

        $args = wp_parse_args( $args, array(
            'post_id'   =>  0,
            'startDate' =>  '',
            'endDate'   =>  'today',
            'pagePath'  =>  ''
        ) );

        extract( $args );

        $post = get_post( $post_id );

        if( empty( $startDate ) ){
            $startDate = date( 'Y-m-d', strtotime( $post->post_date ) );
        }

        $params['metrics'][] = array(
            'expression'        =>  'ga:totalEvents',
            'alias'             =>  esc_html__( 'Video Views', 'streamtube-core' )
        );

        $params['metrics'][] = array(
            'expression'        =>  'ga:uniqueEvents',
            'alias'             =>  esc_html__( 'Unique Video Views', 'streamtube-core' )
        );   

        $params['dimensions'][] = array(
            'name'  =>  'ga:eventLabel'
        );

        $params['dimensionFilters']['ga:eventLabel'][] = get_permalink( $post->ID );

        $params = array_merge( $params, array(
            'startDate' =>  $startDate,
            'endDate'   =>  $endDate
        ) );

        $response = $this->call_api( $params );

        if( is_wp_error( $response ) ){
            return $response;
        }    

        $response = $response[0]['data']['totals'][0]['values'];

        update_post_meta( $post_id, '_videoviews', $response[0] );
        update_post_meta( $post_id, '_uniquevideoviews', $response[1] );

        return compact( 'response', 'params', 'args' );
    }

    /**
     *
     * Update post list pageviews
     * 
     * @return array
     *
     * @since 1.0.8
     * 
     */
    public function update_post_list_pageviews( $query_args = array() ){

        $dimensionFilterClauses = array();

        $query_args = wp_parse_args( $query_args, array(
            'post_type'         =>  'video',
            'posts_per_page'    =>  -1,
            'paged'             =>  1
        ) );     

        extract( $query_args );

        $posts = get_posts( array(
            'post_type'         =>  $post_type,
            'post_status'       =>  'publish',
            'posts_per_page'    =>  $posts_per_page,
            'paged'             =>  $paged
        ) );

        /**
        $meta_query = array(
            array(
                'key'       =>  '_last_seen',
                'value'     =>  date( 'Y-m-d H:i:s', strtotime( current_time( 'mysql', true ) . " {$interval}" ) ),
                'compare'   =>  '>=',
                'type'      =>  'DATETIME'
            )
        );
        **/

        if( ! $posts ){
            return compact( 'query_args' );
        }        

        $params = array(
            'dateRanges'    =>  array(
                'startDate' =>  '2010-01-01',
                'endDate'   =>  'today'
            ),
            'viewId'    =>  $this->get_profile_id(),
            'pageSize'  =>  count( $posts )
        );

        $params['metrics'][] = array(
            'expression'        =>  'ga:pageViews',
            'alias'             =>  esc_html__( 'Page Views', 'streamtube-core' )
        );

        $params['metrics'][] = array(
            'expression'        =>  'ga:uniquePageViews',
            'alias'             =>  esc_html__( 'Unique Page Views', 'streamtube-core' )
        );

        $params['dimensions'][] = array(
            'name'  =>  'ga:pagePath'
        );

        $params['dimensions'][] = array(
            'name'  =>  'ga:pageTitle'
        );

        foreach( $posts as $post ){
            $expressions[] = $this->get_post_path( $post->ID );
        }

        $params['metricFilterClauses'] = array(
            'operator'  =>  'AND',
            'filters'   =>  array(
                array(
                    'metricName'        =>  'ga:pageViews',
                    'operator'          =>  'GREATER_THAN',
                    'comparisonValue'   =>  '0'
                )
            )
        );

        $dimensionFilterClauses[] = array(
            'dimensionName' =>  'ga:hostname',
            'expressions'   =>  $_SERVER['SERVER_NAME'],
            'operator'      =>  'EXACT'
        );

        $dimensionFilterClauses[] = array(
            'dimensionName' =>  'ga:pagePath',
            'expressions'     => $expressions,
            'operator'      =>  'IN_LIST'
        );

        $params['dimensionFilterClauses'] =  array(
            'operator'  =>  'AND',
            'filters'   =>  $dimensionFilterClauses
        );   

        $response = $this->get_reports( $params );

        if( is_wp_error( $response ) ){
            return $response;
        }

        $data = $response[0]['data']['rows'];

        $post_updated = array();

        if( ! is_array( $data ) || count( $data ) == 0 ){
            return false;
        }        

        for ( $i=0;  $i < count( $data );  $i++) {

            $page_path = $data[$i]['dimensions'][0];
            $page_title = $data[$i]['dimensions'][1];

            $page_path = apply_filters( 'streamtube/core/analytics/response/page_path', $page_path, $data );

            $url = untrailingslashit( home_url('/') ) . $page_path;

            $url = apply_filters( 'streamtube/core/analytics/response/page_url', $url, $page_path, $data );

            $post_id = url_to_postid( untrailingslashit( $url ) );

            if( $post_id ){

                $post_url = get_permalink( $post_id );

                $pageviews = (int)$data[$i]['metrics'][0]['values'][0];
                $uniquepageviews = (int)$data[$i]['metrics'][0]['values'][1];

                update_post_meta( $post_id, '_pageviews', $pageviews );
                update_post_meta( $post_id, '_uniquepageviews', $uniquepageviews );

                $posts_updated[] = compact( 'post_id', 'post_url', 'pageviews', 'uniquepageviews' );

                /**
                 *
                 * @param array{
                 *        int $videoviews
                 *        int $uniquevideoviews
                 * }
                 * 
                 */
                do_action( "streamtube/core/post_updated_{$post_id}_postviews", compact( 'pageviews', 'uniquepageviews' ) );                
            }
        }

        $response = compact( 'query_args', 'expressions', 'params', 'response', 'posts_updated' );

        /**
         *
         * Fires after updated into database
         *
         * @param $response
         * 
         */
        do_action( "streamtube/core/updated_post_list_videoviews", $response );

        return $response;
    }

    /**
     *
     * Update post list videoviews
     * 
     * @return array
     *
     * @since 1.0.8
     * 
     */    
    public function update_post_list_videoviews( $query_args = array() ){

        $dimensionFilterClauses = array();

        $query_args = wp_parse_args( $query_args, array(
            'post_type'         =>  'video',
            'posts_per_page'    =>  -1,
            'interval'          =>  '-5 minutes',
            'paged'             =>  1
        ) );         

        extract( $query_args );

        $posts = get_posts( array(
            'post_type'         =>  $post_type,
            'post_status'       =>  'publish',
            'posts_per_page'    =>  $posts_per_page,
            /**
            'meta_query'        =>  array(
                array(
                    'key'       =>  '_last_seen',
                    'compare'   =>  'EXISTS'
                )
            )
            **/
        ) );

        if( ! $posts ){
            return compact( 'query_args' );
        }        

        $params = array(
            'dateRanges'    =>  array(
                'startDate' =>  '2010-01-01',
                'endDate'   =>  'today'
            ),
            'viewId'    =>  $this->get_profile_id(),
            'pageSize'  =>  count( $posts )
        );

        $params['metrics'][] = array(
            'expression'        =>  'ga:totalEvents',
            'alias'             =>  esc_html__( 'Video Views', 'streamtube-core' )
        );

        $params['metrics'][] = array(
            'expression'        =>  'ga:uniqueEvents',
            'alias'             =>  esc_html__( 'Unique Video Views', 'streamtube-core' )
        );   

        $params['dimensions'][] = array(
            'name'  =>  'ga:pagePath'
        );        

        $params['dimensions'][] = array(
            'name'  =>  'ga:eventLabel'
        );

        $expressions = array();

        foreach ( $posts as $post ) {       
            $expressions[] = $this->get_post_path( $post->ID );
        }

        $params['metricFilterClauses'] = array(
            'operator'  =>  'AND',
            'filters'   =>  array(
                array(
                    'metricName'        =>  'ga:totalEvents',
                    'operator'          =>  'GREATER_THAN',
                    'comparisonValue'   =>  '0'
                )
            )
        );        

        $dimensionFilterClauses[] = array(
            'dimensionName' =>  'ga:hostname',
            'expressions'   =>  $_SERVER['SERVER_NAME'],
            'operator'      =>  'EXACT'
        );        

        $dimensionFilterClauses[] = array(
            'dimensionName' =>  'ga:pagePath',
            'expressions'     => $expressions,
            'operator'      =>  'IN_LIST'
        );     
    
        $params['dimensionFilterClauses'] =  array(
            'operator'  =>  'AND',
            'filters'   =>  $dimensionFilterClauses
        ); 

        $response = $this->get_reports( $params );

        if( is_wp_error( $response ) ){
            return $response;
        }

        $post_updated = array();

        $data = $response[0]['data']['rows'];

        if( ! is_array( $data ) || count( $data ) == 0 ){
            return false;
        }

        for ( $i=0;  $i < count( $data );  $i++ ) {

            $page_path = $data[$i]['dimensions'][0];

            $page_path = apply_filters( 'streamtube/core/analytics/response/page_path', $page_path, $data );

            $url = untrailingslashit( home_url('/') ) . $page_path;

            $url = apply_filters( 'streamtube/core/analytics/response/page_url', $url, $page_path, $data );

            $post_id = url_to_postid( untrailingslashit( $url ) );

            if( $post_id ){

                $post_url = get_permalink( $post_id );

                $videoviews         = (int)$data[$i]['metrics'][0]['values'][0];
                $uniquevideoviews   = (int)$data[$i]['metrics'][0]['values'][1];

                update_post_meta( $post_id, '_videoviews', $videoviews );
                update_post_meta( $post_id, '_uniquevideoviews', $uniquevideoviews );

                $posts_updated[] = compact( 'post_id', 'post_url', 'videoviews', 'uniquevideoviews' );

                /**
                 *
                 * Fires after videoviews updated into database
                 *
                 * @param array{
                 *        int $videoviews
                 *        int $uniquevideoviews
                 * }
                 * 
                 */
                do_action( "streamtube/core/updated_post_{$post_id}_videoviews", compact( 'videoviews', 'uniquevideoviews' ) );
            }
        }

        $response = compact( 'query_args', 'expressions', 'params', 'response', 'posts_updated' );

        /**
         *
         * Fires after updated into database
         *
         * @param $response
         * 
         */
        do_action( "streamtube/core/updated_post_list_videoviews", $response );

        return $response;
    }    

    /**
     *
     * Cron job auto update pageviews
     * 
     * @since 1.0.8
     * 
     */
    public function cron_update_post_list_pageviews(){

        if( ! $this->is_connected() ){
            return false;
        }

        $per_page = $this->get_cron_posts_per_page();

        $results = array();

        $post_types = array( 'post', 'video' );

        for ( $i=0; $i < count( $post_types ); $i++) {

            $_paged = (int)get_option( '_update_post_list_pageviews_' . $post_types[$i], 1 );

            $total_posts = wp_count_posts( $post_types[$i], 'readable' )->publish;

            if( $total_posts > 0 ){

                $total_pages = ceil($total_posts/$per_page);

                $paged = min( $_paged, $total_pages );

                $results[$post_types[ $i ]] = $this->update_post_list_pageviews( apply_filters(
                    'streamtube/core/post_list_pageviews_query_args',
                    array(
                        'post_type'         =>  $post_types[$i],
                        'posts_per_page'    =>  $per_page,
                        'paged'             =>  $paged,
                        'max_pages'         =>  $total_pages
                    )
                ) );

                if( $paged >= $total_pages ){
                    $paged = 0;
                }

                update_option( '_update_post_list_pageviews_' . $post_types[$i], $paged+1 );
            }
        }

        return compact( 'results', 'post_types' );
    }

    /**
     *
     * Cron job auto update videoviews
     * 
     * @since 1.0.8
     * 
     */
    public function cron_update_post_list_videoviews(){

        if( ! $this->is_connected() ){
            return false;
        }
        
        $per_page = $this->get_cron_posts_per_page();

        $results = array();

        $post_types = array( 'video' );

        $_paged = (int)get_option( '_update_post_list_videoviews', 1 );

        $total_posts = wp_count_posts( 'video', 'readable' )->publish;

        if( $total_posts == 0 ){
            return;
        }

        $total_pages = ceil($total_posts/$per_page);

        $paged = min( $_paged, $total_pages );

        for ( $i=0; $i < count( $post_types ); $i++) {
            $results = $this->update_post_list_videoviews( apply_filters(
                'streamtube/core/post_list_videoviews_query_args',
                array(
                    'post_type'         =>  $post_types[$i],
                    'posts_per_page'    =>  $per_page,
                    'paged'             =>  $paged,
                    'max_pages'         =>  $total_pages
                )
            ) );            
        }

        if( $paged >= $total_pages ){
            $paged = 0;
        }

        update_option( '_update_post_list_videoviews', $paged+1 );

        return compact( 'results', 'post_types' );
    }

    /**
     *
     * Auto update pageViews and videoViews on hearbeat tick event
     * 
     * @param  array $response
     * @param  string $screen_id
     * @return array
     */
    public function heartbeat_tick( $response, $screen_id ){

        if( ! get_option( 'sitekit_heartbeat_tick', 'on' ) || ! $this->is_connected() ){
            return $response;
        }

        $expiration = (int)get_option( 'sitekit_heartbeat_tick_transient', 60*1*30 );

        if( false !== ($cache = get_transient( 'cache_page_list_views' )) ){
            return array_merge( $response, array(
                'page_list_views'           =>  $cache,
                'page_list_views_cached'    =>  true
            ) );
        }

        $pageviews = $this->cron_update_post_list_pageviews();
        $videoviews = $this->cron_update_post_list_videoviews();

        $data = compact( 'pageviews', 'videoviews' );

        if( $expiration > 0 ){
            set_transient( 'cache_page_list_views', $data, $expiration );
        }

        return array_merge( $response, array(
            'page_list_views'   =>  $data
        ) );
    }
}